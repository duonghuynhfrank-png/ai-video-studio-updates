"""Explicit browser sign-in to a configured app account server. No API billing."""
import argparse
import base64
import ctypes
from ctypes import wintypes
import hashlib
import http.server
import json
import os
from pathlib import Path
import secrets
import sys
sys.stdout.reconfigure(encoding='utf-8');sys.stderr.reconfigure(encoding='utf-8')
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from contextlib import contextmanager
import msvcrt

class AccountError(Exception):
    pass

DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.appdata'


def provider_config():
    """Publisher supplied settings; consumers do not enter OAuth/server URLs."""
    path = Path(__file__).with_name('account-provider.json')
    if not path.is_file():
        return {}
    value = json.loads(path.read_text('utf-8-sig'))
    if not isinstance(value, dict):
        raise AccountError('Cấu hình đăng nhập của bản phát hành không hợp lệ.')
    client = value.get('googleDesktopClientId', '')
    if client and (not isinstance(client, str) or not client.endswith('.apps.googleusercontent.com') or any(c.isspace() for c in client)):
        raise AccountError('Mã đăng nhập Google của bản phát hành không hợp lệ.')
    return value


def google_parameters(client, redirect, state, nonce, verifier):
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
    return {'client_id': client, 'redirect_uri': redirect, 'response_type': 'code',
            'scope': 'openid email profile ' + DRIVE_SCOPE, 'state': state, 'nonce': nonce,
            'code_challenge': challenge, 'code_challenge_method': 'S256',
            'access_type': 'offline', 'prompt': 'select_account consent'}


def google_callback(query, expected_state):
    def one(name):
        values = query.get(name, [])
        if len(values) > 1:
            raise AccountError('Phản hồi đăng nhập không hợp lệ.')
        return values[0] if values else ''
    if not secrets.compare_digest(one('state'), expected_state):
        raise AccountError('Phản hồi đăng nhập không khớp; hãy thử lại.')
    if one('error'):
        raise AccountError('Bạn đã hủy đăng nhập Google.')
    code = one('code')
    if not code:
        raise AccountError('Google chưa trả mã đăng nhập.')
    return code


def google_identity(token, client, nonce=None):
    # Restrict signature verification to Google's fixed JWKS, never token URLs.
    import jwt
    try:
        if jwt.get_unverified_header(token).get('alg') != 'RS256':
            raise ValueError()
        key = jwt.PyJWKClient('https://www.googleapis.com/oauth2/v3/certs', timeout=15).get_signing_key_from_jwt(token)
        claims = jwt.decode(token, key.key, algorithms=['RS256'], audience=client,
                            options={'require': ['iss', 'sub', 'aud', 'exp', 'iat'] + (['nonce'] if nonce else [])}, leeway=5)
        if claims['iss'] not in ('https://accounts.google.com', 'accounts.google.com'):
            raise ValueError()
        if claims.get('azp', client) != client or not isinstance(claims['sub'], str) or not claims['sub']:
            raise ValueError()
        if (nonce and not secrets.compare_digest(str(claims['nonce']), nonce)) or claims.get('email_verified') is not True:
            raise ValueError()
        return {k: claims.get(k, '') for k in ('sub', 'email', 'name', 'picture')}
    except Exception:
        raise AccountError('Chưa xác minh được tài khoản Google; hãy đăng nhập lại.') from None


def google_stored(store):
    path = store / 'google-session.dpapi'
    return json.loads(protect(path.read_bytes(), True)) if path.exists() else None


@contextmanager
def google_session_lock(store):
    store.mkdir(parents=True, exist_ok=True)
    with (store / 'google-session.lock').open('a+b') as handle:
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        try:
            yield
        finally:
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)


def google_login(store):
    config = provider_config()
    client = config.get('googleDesktopClientId')
    if not client:
        raise AccountError('Đăng nhập Google chưa được kích hoạt trong bản này.')
    verifier, state, nonce = (secrets.token_urlsafe(48) for _ in range(3))
    result = {}

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            parsed = urllib.parse.urlsplit(self.path)
            if parsed.path != '/callback' or len(self.path) > 16384:
                self.send_error(404)
                return
            try:
                result['code'] = google_callback(urllib.parse.parse_qs(parsed.query), state)
                message = 'Google sign-in complete. You may return to AI Video Studio.'
                status_code = 200
            except AccountError as error:
                result['error'] = str(error)
                message = 'Sign-in was not completed. Return to AI Video Studio to try again.'
                status_code = 400
            self.send_response(status_code)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(message.encode('utf-8'))

    with http.server.HTTPServer(('127.0.0.1', 0), Handler) as server:
        server.timeout = 1
        redirect = f'http://127.0.0.1:{server.server_port}/callback'
        params = google_parameters(client, redirect, state, nonce, verifier)
        url = 'https://accounts.google.com/o/oauth2/v2/auth?' + urllib.parse.urlencode(params)
        if not webbrowser.open(url):
            raise AccountError('Chưa mở được trình duyệt đăng nhập.')
        deadline = time.monotonic() + 600
        while not result and time.monotonic() < deadline:
            server.handle_request()
    if result.get('error'):
        raise AccountError(result['error'])
    if not result.get('code'):
        raise AccountError('Đăng nhập hết thời gian; hãy thử lại.')
    fields = {'grant_type': 'authorization_code', 'client_id': client,
              'code': result['code'], 'code_verifier': verifier, 'redirect_uri': redirect}
    # Google's Desktop client download may contain this public-client value.
    if config.get('googleDesktopClientSecret'):
        fields['client_secret'] = config['googleDesktopClientSecret']
    req = urllib.request.Request('https://oauth2.googleapis.com/token',
        data=urllib.parse.urlencode(fields).encode(),
        headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'})
    try:
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=20) as response:
            raw = response.read(256 * 1024 + 1)
            if len(raw) > 256 * 1024:
                raise ValueError()
            tokens = json.loads(raw)
    except (urllib.error.URLError, TimeoutError, ValueError):
        raise AccountError('Chưa hoàn tất đăng nhập Google; hãy thử lại.') from None
    profile = google_identity(tokens.get('id_token', ''), client, nonce)
    scopes = str(tokens.get('scope', '')).split()
    encrypted = protect(json.dumps({'clientId': client, 'profile': profile, 'sessionId': secrets.token_hex(32),
        'accessToken': tokens.get('access_token', ''), 'refreshToken': tokens.get('refresh_token', ''),
        'expiresAt': time.time() + float(tokens.get('expires_in', 0)), 'scopes': scopes}).encode())
    temporary = store / ('google-session.' + secrets.token_hex(8) + '.tmp')
    try:
        temporary.write_bytes(encrypted)
        with google_session_lock(store):
            temporary.replace(store / 'google-session.dpapi')
    finally:
        temporary.unlink(missing_ok=True)
    return status(store)

def google_access(store, expected_subject=None):
    with google_session_lock(store):
        saved = google_stored(store)
    original_session = dict(saved) if saved else None
    config = provider_config()
    if not saved or saved.get('clientId') != config.get('googleDesktopClientId'):
        raise AccountError('Đăng nhập Gmail để đồng bộ Data.')
    if expected_subject and saved['profile']['sub'] != expected_subject:
        raise AccountError('Tài khoản đã đổi; dừng đồng bộ để giữ Data riêng.')
    if DRIVE_SCOPE not in saved.get('scopes', []):
        raise AccountError('Đăng nhập lại Gmail và cho phép đồng bộ dữ liệu ứng dụng.')
    if time.time() + 60 >= saved.get('expiresAt', 0):
        if not saved.get('refreshToken'):
            raise AccountError('Đăng nhập lại Gmail để tiếp tục đồng bộ.')
        fields = {'grant_type': 'refresh_token', 'client_id': saved['clientId'], 'refresh_token': saved['refreshToken']}
        if config.get('googleDesktopClientSecret'):
            fields['client_secret'] = config['googleDesktopClientSecret']
        req = urllib.request.Request('https://oauth2.googleapis.com/token', data=urllib.parse.urlencode(fields).encode(),
                                     headers={'Content-Type': 'application/x-www-form-urlencoded'})
        try:
            with urllib.request.build_opener(NoRedirect()).open(req, timeout=20) as response:
                tokens = json.loads(response.read(256 * 1024))
        except (urllib.error.URLError, TimeoutError, ValueError):
            raise AccountError('Chưa gia hạn được đăng nhập Gmail; Data vẫn được giữ trên máy.') from None
        if not tokens.get('access_token'):
            raise AccountError('Đăng nhập Gmail cần được kết nối lại.')
        if tokens.get('id_token'):
            identity = google_identity(tokens['id_token'], saved['clientId'])
            if identity['sub'] != saved['profile']['sub']:
                raise AccountError('Google trả về tài khoản khác; dừng đồng bộ.')
        saved.update(accessToken=tokens['access_token'], expiresAt=time.time() + float(tokens.get('expires_in', 0)))
        # A logout that happened during renewal must not recreate its session.
        temporary = store / ('google-session.' + secrets.token_hex(8) + '.tmp')
        try:
            temporary.write_bytes(protect(json.dumps(saved).encode()))
            with google_session_lock(store):
                current = google_stored(store)
                if current != original_session:
                    raise AccountError('Phiên Gmail đã đổi; dừng đồng bộ.')
                temporary.replace(store / 'google-session.dpapi')
        finally:
            temporary.unlink(missing_ok=True)
    return saved['accessToken']

class Blob(ctypes.Structure):
    _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]

def protect(raw, decrypt=False):
    if os.name != 'nt':
        raise AccountError('Credential protection requires Windows.')
    buffer = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    source = Blob(len(raw), buffer)
    target = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    fn = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    fn.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    fn.restype = wintypes.BOOL
    if not fn(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(target)):
        raise AccountError('Không mở được phiên đăng nhập trên máy này; hãy đăng nhập lại.')
    try:
        return ctypes.string_at(target.data, target.size)
    finally:
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree(target.data)

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def server_url(store):
    path = store / 'account-config.json'
    value = json.loads(path.read_text('utf-8')).get('serverUrl', '') if path.exists() else ''
    value = value or provider_config().get('serverUrl', '')
    if not value:
        return ''
    u = urllib.parse.urlsplit(value)
    if u.scheme != 'https' or not u.hostname or u.username or u.password or u.query or u.fragment:
        raise AccountError('Máy chủ tài khoản phải dùng HTTPS.')
    return value.rstrip('/')

def request(base, path, data=None, token=None):
    headers = {'Accept': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = json.dumps(data).encode() if data is not None else None
    if body is not None:
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(base + path, data=body, headers=headers)
    try:
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=15) as response:
            raw = response.read(256 * 1024 + 1)
            if len(raw) > 256 * 1024:
                raise AccountError('Phản hồi máy chủ quá lớn.')
            value = json.loads(raw)
            if not isinstance(value, dict):
                raise AccountError('Máy chủ trả dữ liệu không hợp lệ.')
            return value
    except urllib.error.HTTPError:
        raise AccountError('Máy chủ từ chối yêu cầu. Kiểm tra cấu hình hoặc đăng nhập lại.') from None
    except (urllib.error.URLError, TimeoutError):
        raise AccountError('Không kết nối được máy chủ tài khoản.') from None

def stored(store):
    path = store / 'session.dpapi'
    return json.loads(protect(path.read_bytes(), True)) if path.exists() else None

def status(store):
    config = provider_config()
    if config.get('googleDesktopClientId'):
        saved = google_stored(store)
        result = {'connected': bool(saved and saved.get('clientId') == config['googleDesktopClientId']),
                  'providers': {'google': True, 'facebook': False}, 'projectSync': False,
                  'credentialStorage': 'windows-dpapi', 'signInMethod': 'system-browser'}
        if result['connected']:
            result['profile'] = saved['profile']
            result['projectSync'] = DRIVE_SCOPE in saved.get('scopes', []) and bool(saved.get('accessToken'))
            result['syncProvider'] = 'google-drive-appdata'
            if not result['projectSync']:
                result['message'] = 'Đăng nhập lại Gmail để cấp quyền đồng bộ Data.'
        return result
    base = server_url(store)
    result = {'connected': False, 'providers': {'google': False, 'facebook': False}, 'projectSync': False, 'credentialStorage': 'windows-dpapi'}
    if not base:
        result['message'] = 'Đăng nhập Google chưa được kích hoạt trong bản này.'
        return result
    cap = request(base, '/v1/accounts/capabilities')
    if cap.get('schemaVersion') != 1:
        raise AccountError('Phiên bản máy chủ chưa tương thích.')
    result['providers'] = cap.get('providers', {})
    saved = stored(store)
    if saved and saved.get('serverUrl') == base:
        result['profile'] = request(base, '/v1/accounts/me', token=saved['token'])['profile']
        result['connected'] = True
    return result

def login(store, provider):
    if provider == 'google' and provider_config().get('googleDesktopClientId'):
        return google_login(store)
    base = server_url(store)
    if not base or provider not in ('google', 'facebook'):
        raise AccountError('Chưa cấu hình máy chủ đăng nhập.')
    if not status(store)['providers'].get(provider):
        raise AccountError('Nhà cung cấp đăng nhập chưa được cấu hình trên máy chủ.')
    verifier = secrets.token_urlsafe(48)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
    ticket = request(base, '/v1/accounts/device/start', {'provider': provider, 'challenge': challenge})
    auth = ticket['authorizationUrl']
    if not auth.startswith(base + '/auth/'):
        raise AccountError('Địa chỉ xác thực không thuộc máy chủ đã chọn.')
    if not webbrowser.open(auth):
        raise AccountError('Không mở được trình duyệt đăng nhập.')
    expires = time.monotonic() + min(600, int(ticket['expiresIn']))
    while time.monotonic() < expires:
        time.sleep(3)
        result = request(base, '/v1/accounts/device/poll', {'deviceId': ticket['deviceId'], 'verifier': verifier})
        if result.get('status') == 'pending':
            continue
        if result.get('status') != 'complete' or not result.get('token'):
            raise AccountError('Đăng nhập bị hủy hoặc hết hạn.')
        encrypted = protect(json.dumps({'serverUrl': base, 'token': result['token']}).encode())
        target = store / 'session.dpapi'
        temporary = store / 'session.dpapi.tmp'
        temporary.write_bytes(encrypted)
        temporary.replace(target)
        return status(store)
    raise AccountError('Đăng nhập hết thời gian; hãy thử lại.')

def logout(store):
    with google_session_lock(store):
        (store / 'google-session.dpapi').unlink(missing_ok=True)
    saved = stored(store)
    base = server_url(store)
    if saved and saved.get('serverUrl') == base:
        try:
            request(base, '/v1/accounts/logout', {}, saved['token'])
        except AccountError:
            pass
    (store / 'session.dpapi').unlink(missing_ok=True)
    return status(store)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['status', 'login', 'logout'])
    parser.add_argument('--store', required=True)
    parser.add_argument('--provider', choices=['google', 'facebook'])
    args = parser.parse_args()
    store = Path(args.store); store.mkdir(parents=True, exist_ok=True)
    result = login(store, args.provider) if args.operation == 'login' else logout(store) if args.operation == 'logout' else status(store)
    print(json.dumps(result, ensure_ascii=False))

if __name__ == '__main__':
    try:
        main()
    except AccountError as exc:
        print(str(exc), file=sys.stderr); sys.exit(1)
    except Exception:
        print('Không xử lý được tài khoản; dữ liệu Project vẫn được giữ.', file=sys.stderr); sys.exit(1)
