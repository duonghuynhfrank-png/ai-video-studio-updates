"""Own Studio account. Publisher supplies endpoint; credentials arrive on stdin.

Sessions use Windows DPAPI. No Google/ChatGPT API calls or browser credentials.
"""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import secrets
import sys
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from account_client import protect, NoRedirect, AccountError
import studio_http

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')


def provider_config():
    path = Path(__file__).with_name('studio-account-provider.json')
    return json.loads(path.read_text('utf-8-sig')) if path.is_file() else {}


def server_url(config=None):
    config = provider_config() if config is None else config
    value = config.get('serverUrl', '')
    if not value:
        return ''
    url = urllib.parse.urlsplit(value)
    local = config.get('allowLoopbackDevelopment') is True and url.hostname == '127.0.0.1' and url.scheme == 'http'
    if (url.scheme != 'https' and not local) or not url.hostname or url.username or url.password or url.query or url.fragment or url.path not in ('', '/'):
        raise AccountError('Địa chỉ tài khoản của bản phát hành chưa hợp lệ.')
    return value.rstrip('/')


def request(base, path, token=None, data=None, method=None, maximum=8 * 1024**2, headers=None, timeout=120):
    if not path.startswith('/v1/') or '\\' in path or '..' in path:
        raise AccountError('Yêu cầu tài khoản chưa hợp lệ.')
    header = {'Accept': 'application/json', 'User-Agent': 'AI-Video-Studio/1.0 (Windows; account-sync)', **(headers or {})}
    if token:
        header['Authorization'] = 'Bearer ' + token
    if isinstance(data, dict):
        data = json.dumps(data, ensure_ascii=False).encode('utf-8')
        header['Content-Type'] = 'application/json'
    req = urllib.request.Request(base + path, data=data, headers=header, method=method or ('POST' if data is not None else 'GET'))
    return studio_http.open_response(req, timeout)


def json_request(base, path, token=None, data=None):
    # Two bounded read attempts fit within the desktop status deadline.
    # Login/register/logout and all writes are never automatically repeated.
    reading = data is None
    return studio_http.json_reply(
        lambda: request(base, path, token, data, timeout=8 if reading else 20),
        retry=reading)



@contextmanager
def session_lock(store):
    import msvcrt
    store.mkdir(parents=True, exist_ok=True)
    with (store / 'studio-session.lock').open('a+b') as handle:
        handle.seek(0); handle.write(b'0'); handle.flush(); handle.seek(0)
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            yield
        finally:
            handle.seek(0); msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)


def stored(store):
    path = store / 'studio-session.dpapi'
    return json.loads(protect(path.read_bytes(), True)) if path.exists() else None


def subject(saved):
    return saved['serverId'] + ':' + saved['profile']['id']


def check_binding(store, saved):
    path = store.parent / '.sync' / 'account.json'
    binding = json.loads(path.read_text('utf-8')) if path.is_file() else {}
    if binding.get('account') not in (None, hashlib.sha256(subject(saved).encode()).hexdigest()):
        raise AccountError('Kho Data trên máy đã thuộc tài khoản khác. Chưa ghép Data để tránh lẫn tài khoản.')


def local_status(store, config=None):
    """Read the DPAPI session for immediate UI, never authorize cloud access."""
    config = provider_config() if config is None else config
    base = server_url(config)
    result = {'connected': False, 'sessionSaved': False, 'sessionVerified': False,
              'passwordLogin': bool(base), 'registration': bool(base),
              'preview': config.get('allowLoopbackDevelopment') is True,
              'crossDeviceSync': bool(base and base.startswith('https://'))}
    with session_lock(store):
        saved = stored(store)
    if not saved:
        return result
    permitted_move = (config.get('migrateFromLoopback') is True and
        saved.get('base') == 'http://127.0.0.1:43821' and
        config.get('serverId') == saved.get('serverId'))
    if (saved.get('base') != base and not permitted_move) or (config.get('serverId') and saved.get('serverId') != config['serverId']):
        return {**result, 'message': 'Địa chỉ tài khoản đã đổi; cần xác minh lại phiên đăng nhập.'}
    check_binding(store, saved)
    return {**result, 'sessionSaved': True, 'profile': saved['profile'], 'serverId': saved['serverId']}


def status(store, config=None):
    config = provider_config() if config is None else config
    base = server_url(config)
    result = {**local_status(store, config), 'connected': False, 'passwordLogin': False, 'registration': False, 'projectSync': False,
              'preview': config.get('allowLoopbackDevelopment') is True,
              'crossDeviceSync': bool(base and base.startswith('https://'))}
    if not base:
        return {**result, 'message': 'Nhà phát hành chưa đưa máy chủ tài khoản lên mạng.'}
    try:
        caps = json_request(base, '/v1/accounts/capabilities')
    except AccountError as error:
        return {**result, 'serviceReachable': False,
            'passwordLogin': bool(base and not result['preview']),
            'registration': bool(base and not result['preview']),
            'connectionError': studio_http.public_error(error),
            'message': ('Bản này đang dùng máy chủ thử nội bộ; máy khác chưa thể đăng nhập.'
                if result['preview'] else str(error))}

    if caps.get('schemaVersion') != 2:
        raise AccountError('Máy chủ tài khoản cần được cập nhật.')
    if config.get('serverId') and config['serverId'] != caps.get('serverId'):
        raise AccountError('Máy chủ tài khoản trả về chưa đúng. Dừng đồng bộ để giữ riêng Data.')
    result.update(serviceReachable=True)
    result.update({k: caps.get(k, False) for k in ('passwordLogin', 'registration', 'projectSync')})
    with session_lock(store):
        saved = stored(store)
    if not saved:
        return result
    moving = saved.get('base') != base
    permitted_move = (config.get('migrateFromLoopback') is True and
        saved.get('base') == 'http://127.0.0.1:43821' and
        config.get('serverId') == saved.get('serverId') == caps.get('serverId'))
    if (moving and not permitted_move) or saved.get('serverId') != caps.get('serverId'):
        raise AccountError('Máy chủ tài khoản đã đổi. Vui lòng đăng nhập lại trước khi đồng bộ.')
    try:
        me = json_request(base, '/v1/accounts/me', saved['token'])
    except AccountError as exc:
        if getattr(exc, 'status', 0) == 401:
            with session_lock(store):
                if stored(store) == saved:
                    (store / 'studio-session.dpapi').unlink(missing_ok=True)
            return {**result, 'sessionSaved': False, 'profile': {},
                'message': 'Phiên đăng nhập đã hết hạn; đăng nhập lại để đồng bộ.'}
        return {**result, 'serviceReachable': False,
            'connectionError': studio_http.public_error(exc), 'message': str(exc)}
    if me.get('serverId') != saved['serverId'] or me.get('profile', {}).get('id') != saved['profile']['id']:
        raise AccountError('Tài khoản trả về chưa khớp; dừng đồng bộ.')
    check_binding(store, saved)
    if moving:
        with session_lock(store):
            if stored(store) != saved:
                raise AccountError('Phiên đăng nhập đã thay đổi. Vui lòng kiểm tra lại.')
            new_saved = {**saved, 'base': base}
            path = store / ('studio-session.' + secrets.token_hex(8) + '.tmp')
            try:
                path.write_bytes(protect(json.dumps(new_saved).encode()))
                os.replace(path, store / 'studio-session.dpapi')
            finally:
                path.unlink(missing_ok=True)
    return {**result, 'connected': True, 'sessionSaved': True, 'sessionVerified': True, 'profile': me['profile'], 'serverId': me['serverId']}


def sign_in(store, operation, credentials, config=None):
    config = provider_config() if config is None else config
    base = server_url(config)
    if not base:
        raise AccountError('Máy chủ tài khoản chưa được phát hành.')
    # Serialize register/login/logout so cancellation cannot recreate a session.
    with session_lock(store):
        credentials = dict(credentials)
        credentials['username'] = unicodedata.normalize('NFKC', str(credentials.get('username', ''))).strip().casefold()
        if operation == 'login' and config.get('loginMethods') is True:
            method = json_request(base, '/v1/accounts/login-method', data={'username': credentials['username']})
            if method.get('method') == 'scrypt-prehash-v1':
                import re
                salt = method.get('salt', '')
                password = credentials.pop('password', None)
                if not isinstance(salt, str) or not re.fullmatch(r'[a-f0-9]{32}', salt) or not isinstance(password, str) or not 10 <= len(password) <= 128:
                    raise AccountError('Thông tin xác minh tài khoản cũ chưa hợp lệ.')
                credentials['passwordProof'] = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt),
                    n=2**17, r=8, p=1, maxmem=256 * 1024**2, dklen=32).hex()
            elif method.get('method') != 'password-v1':
                raise AccountError('Bản app chưa hỗ trợ cách xác minh tài khoản này.')
        value = json_request(base, '/v1/accounts/' + operation, data=credentials)
        saved = {**value, 'base': base}
        try:
            if not isinstance(saved.get('token'), str) or not saved.get('profile', {}).get('id') or not saved.get('serverId'):
                raise AccountError('Máy chủ chưa cấp phiên đăng nhập hợp lệ.')
            if config.get('serverId') and config['serverId'] != saved['serverId']:
                raise AccountError('Máy chủ tài khoản trả về chưa đúng. Data trên máy được giữ.')
            check_binding(store, saved)
            path = store / ('studio-session.' + secrets.token_hex(8) + '.tmp')
            try:
                path.write_bytes(protect(json.dumps(saved).encode()))
                os.replace(path, store / 'studio-session.dpapi')
            finally:
                path.unlink(missing_ok=True)
        except Exception:
            json_request(base, '/v1/accounts/logout', value.get('token'), data={})
            raise
    return {**local_status(store, config), 'connected': True, 'sessionVerified': True,
            'profile': saved['profile'], 'serverId': saved['serverId']}


def logout(store, config=None):
    with session_lock(store):
        saved = stored(store)
        if saved:
            # Server acknowledgement is required to revoke this device's token.
            try:
                json_request(server_url(config), '/v1/accounts/logout', saved['token'], data={})
            except AccountError as exc:
                if getattr(exc, 'status', 0) != 401:
                    raise
        (store / 'studio-session.dpapi').unlink(missing_ok=True)
    return status(store, config)


def authorized(store):
    result = status(store)
    if not result.get('connected'):
        raise AccountError('Đăng nhập AI Video Studio để đồng bộ Data.')
    with session_lock(store):
        saved = stored(store)
    if not saved or saved['profile']['id'] != result['profile']['id']:
        raise AccountError('Phiên đăng nhập đã thay đổi; dừng đồng bộ.')
    return saved


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['local-status', 'status', 'register', 'login', 'logout'])
    parser.add_argument('--store', required=True)
    args = parser.parse_args()
    store = Path(args.store)
    if args.operation in ('register', 'login'):
        raw = sys.stdin.buffer.read(8193)
        if len(raw) > 8192:
            raise AccountError('Thông tin đăng nhập vượt giới hạn.')
        credentials = json.loads(raw)
        if not isinstance(credentials, dict):
            raise AccountError('Thông tin đăng nhập chưa hợp lệ.')
        result = sign_in(store, args.operation, credentials)
    else:
        result = (logout(store) if args.operation == 'logout' else local_status(store) if args.operation == 'local-status' else status(store))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except AccountError as exc:
        print(str(exc), file=sys.stderr); sys.exit(1)
    except Exception:
        print('Chưa thực hiện được thao tác tài khoản. Data trên máy được giữ.', file=sys.stderr); sys.exit(1)
