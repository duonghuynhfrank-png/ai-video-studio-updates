"""Verify publisher signatures, notify, and stage app updates without reinstalling."""
import argparse
import base64
import contextlib
import ctypes
import datetime
import errno
import socket
import hashlib
import json
import os
import re
import ssl
import urllib.error
from pathlib import Path
import shutil
import sys
import time
import urllib.parse
import uuid
import zipfile
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from release_io import atomic_json, child, digest, download, open_url, read_json, validate_url

MAX_PACKAGE = 2 * 1024**3
MAX_EXTRACTED = 4 * 1024**3


def locate_installation():
    for parent in Path(__file__).resolve().parents:
        if (parent / 'installation.json').is_file():
            return parent
        if (parent / 'App' / 'installation.json').is_file():
            return parent / 'App'
    return None


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def config(root):
    root = Path(root)
    trust_file = root / 'update-trust.json'
    if not trust_file.is_file():
        return {}
    result = read_json(trust_file)
    settings_file = root / 'updates' / 'client.json'
    if settings_file.is_file():
        settings = read_json(settings_file)
        # Endpoint is editable. The public key remains pinned to this publisher.
        result['feedUrl'] = settings.get('feedUrl', result.get('feedUrl', ''))
    return result


def set_feed(root, url):
    validate_url(url)
    trust = config(root)
    if not trust.get('publicKeyPem'):
        raise ValueError('Bản app chưa có khóa xác minh của nhà phát hành.')
    atomic_json(Path(root) / 'updates' / 'client.json', {'schemaVersion': 1, 'feedUrl': url})


def verify_envelope(envelope, public_key):
    if envelope.get('algorithm') != 'RSA-PSS-SHA256':
        raise ValueError('Chữ ký bản phát hành không được hỗ trợ.')
    encoded = base64.b64decode(envelope['payload'], validate=True)
    signature = base64.b64decode(envelope['signature'], validate=True)
    key = serialization.load_pem_public_key(public_key.encode('ascii'))
    if not isinstance(key, rsa.RSAPublicKey) or key.key_size < 3072:
        raise ValueError('Khóa nhà phát hành không hợp lệ.')
    key.verify(signature, encoded, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32), hashes.SHA256())
    release = json.loads(encoded)
    if release.get('schemaVersion') != 1 or release.get('target') != 'windows-x64' or release.get('applicationId') != 'vn.aivideostudio':
        raise ValueError('Bản phát hành không dành cho ứng dụng này.')
    if not isinstance(release.get('sequence'), int) or release['sequence'] <= 0:
        raise ValueError('Thứ tự bản phát hành không hợp lệ.')
    parts = release.get('version', '').split('.')
    if len(parts) != 3 or any(not p.isdigit() for p in parts):
        raise ValueError('Phiên bản không hợp lệ.')
    package = release['package']
    if not isinstance(package.get('bytes'), int) or not 0 < package['bytes'] <= MAX_PACKAGE:
        raise ValueError('Gói cập nhật vượt giới hạn cho phép.')
    if len(package.get('sha256', '')) != 64 or any(c not in '0123456789abcdef' for c in package['sha256']):
        raise ValueError('Checksum gói cập nhật không hợp lệ.')
    return release


def status(root):
    root = Path(root)
    settings = config(root)
    result = {'releaseFeedConfigured': bool(settings.get('feedUrl') and settings.get('publicKeyPem')), 'releaseFeedUrl': settings.get('feedUrl', ''), 'remoteUpdatePhase': 'not-configured', 'automaticRemoteUpdates': not (root / 'updates' / 'REMOTE_PAUSE').exists()}
    status_file = root / 'updates' / 'remote-status.json'
    if status_file.exists():
        result.update(read_json(status_file))
    if result.get('remoteUpdatePhase') in ('downloading', 'verifying'):
        try:
            last = datetime.datetime.fromisoformat(result.get('transferUpdatedAt') or result['checkedAt'])
            age = (datetime.datetime.now(datetime.timezone.utc) - last).total_seconds()
            if age > 180 and not background_running(root):
                result.update(remoteUpdatePhase='failed',
                              updateError='Lượt cập nhật bị gián đoạn. Bấm Cập nhật ngay để tiếp tục; bản đang dùng được giữ.')
        except (KeyError, ValueError, TypeError):
            result.update(remoteUpdatePhase='failed', updateError='Lượt cập nhật cũ đã dừng; bấm Cập nhật ngay để thử lại.')
    return result


@contextlib.contextmanager
def stage_lock():
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    kernel.CreateMutexW.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    kernel.ReleaseMutex.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    handle = kernel.CreateMutexW(None, False, 'Local\\AIVideoStudioLocalPublish')
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    acquired = kernel.WaitForSingleObject(handle, 0) in (0, 0x80)
    try:
        if not acquired:
            raise ValueError('Một bản cập nhật khác đang được chuẩn bị. Hãy thử lại sau.')
        yield
    finally:
        if acquired:
            kernel.ReleaseMutex(handle)
        kernel.CloseHandle(handle)


def extract_verified(archive, destination, release, progress=None, max_seconds=600, resume=False):
    """Validate the complete ZIP first, then hash each file as it is written.

    No second full disk read is needed after extraction. Activation still
    checks the candidate independently before changing the running version.
    """
    started = time.monotonic()
    destination = Path(destination).absolute()
    # Staging always uses a new private candidate, never an existing runtime.
    # Validate existing ancestors once; validate every ZIP path lexically before
    # writing. Resolving all ancestors again for 12,000 files stalls slow PCs.
    cursor = destination
    while cursor != cursor.parent:
        if cursor.is_symlink() or cursor.is_junction():
            raise ValueError('Không giải nén qua thư mục liên kết.')
        cursor = cursor.parent
    if not resume and destination.exists() and any(destination.iterdir()):
        raise ValueError('Bản cập nhật phải dùng thư mục phiên bản mới, trống.')
    reserved = {'CON', 'PRN', 'AUX', 'NUL', *('COM'+str(i) for i in range(1,10)), *('LPT'+str(i) for i in range(1,10))}
    def target_path(path):
        raw = path.replace('\\', '/')
        parts = raw.split('/')
        if not raw or raw.startswith('/') or any(not p or p in ('.','..') or ':' in p or p.endswith((' ','.')) or p.split('.')[0].upper() in reserved for p in parts):
            raise ValueError('Đường dẫn trong bản phát hành không hợp lệ.')
        return destination.joinpath(*parts)

    def pulse(done, total, count, files):
        if time.monotonic() - started > max_seconds:
            raise TimeoutError('Giải nén/xác minh quá thời gian cho phép; giữ bản đang dùng và sẽ thử lại.')
        if progress:
            progress(done, total, count, files)

    with zipfile.ZipFile(archive) as source:
        entries = source.infolist()
        if len(entries) > 30000 or sum(item.file_size for item in entries) > MAX_EXTRACTED:
            raise ValueError('Gói cập nhật có cấu trúc quá lớn.')
        seen, targets = set(), {}
        for item in entries:
            path = item.filename.rstrip('/')
            if not path:
                continue
            key = path.replace('\\', '/').casefold()
            if key in seen or ((item.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError('Gói cập nhật có file trùng hoặc liên kết.')
            seen.add(key)
            target = target_path(path)
            if key.split('/')[0] == 'models':
                raise ValueError('Gói cập nhật app không được ghi đè kho model.')
            if not item.is_dir():
                targets[key] = (item, target)
        if 'package-manifest.json' not in targets:
            raise ValueError('Thiếu manifest bản cập nhật.')
        item, manifest_path = targets.pop('package-manifest.json')
        if item.file_size > 16 * 1024**2:
            raise ValueError('Manifest cập nhật quá lớn.')
        manifest_bytes = source.read(item)
        manifest = json.loads(manifest_bytes.decode('utf-8-sig'))
        if manifest.get('schemaVersion') != 1 or manifest.get('version') != release['version'] or manifest.get('target') != 'windows-x64':
            raise ValueError('Manifest không khớp bản phát hành đã ký.')
        required = {'ai_video_studio.exe', 'flutter_windows.dll', 'data/app.so', '.installed', 'maintenance/launch.ps1', 'maintenance/update.common.ps1', 'maintenance/uninstall.ps1', 'maintenance/rollback.ps1'}
        recorded = {}
        for file in manifest['files']:
            key = file['path'].replace('\\', '/').casefold()
            if key in recorded:
                raise ValueError('Manifest có đường dẫn trùng.')
            recorded[key] = file
        if not required.issubset(recorded) or recorded.keys() != targets.keys():
            raise ValueError('Manifest không mô tả đầy đủ các file cập nhật.')
        for key, (item, _) in targets.items():
            file = recorded[key]
            if item.file_size != file['bytes'] or not re.fullmatch('[0-9a-f]{64}', file['sha256']):
                raise ValueError('File cập nhật sai kích thước/checksum: ' + file['path'])
        if resume and destination.exists():
            allowed = set(targets) | {'package-manifest.json'}
            for base, directories, files in os.walk(destination, followlinks=False):
                for name in directories + files:
                    existing = Path(base) / name
                    if existing.is_symlink() or existing.is_junction():
                        raise ValueError('Không tiếp tục qua file/thư mục liên kết.')
                    if existing.is_file() and existing.relative_to(destination).as_posix().casefold() not in allowed:
                        raise ValueError('Thư mục đang chuẩn bị có file ngoài manifest.')
            if manifest_path.is_file() and manifest_path.read_bytes() != manifest_bytes:
                raise ValueError('Manifest trong bản đang chuẩn bị đã đổi.')
        total = sum(item.file_size for item, _ in targets.values())
        done = count = 0
        pulse(done, total, count, len(targets))
        for key, (item, target) in targets.items():
            target.parent.mkdir(parents=True, exist_ok=True)
            if resume and target.is_file() and target.stat().st_size == item.file_size and digest(target) == recorded[key]['sha256']:
                done += item.file_size
                count += 1
                pulse(done, total, count, len(targets))
                continue
            hasher = hashlib.sha256()
            if resume and target.exists():
                # Replace this candidate entry, never truncate a hard-linked
                # file that could also belong to an existing installation.
                target.unlink()
            with source.open(item) as incoming, target.open('xb') as output:
                while chunk := incoming.read(1024 * 1024):
                    output.write(chunk)
                    hasher.update(chunk)
                    done += len(chunk)
                    pulse(done, total, count, len(targets))
            if hasher.hexdigest() != recorded[key]['sha256']:
                raise ValueError('File cập nhật sai checksum: ' + recorded[key]['path'])
            count += 1
            pulse(done, total, count, len(targets))
        # Manifest is written last; an interrupted candidate is never pending.
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        if not manifest_path.exists():
            with manifest_path.open('xb') as output:
                output.write(manifest_bytes)
    return hashlib.sha256(manifest_bytes).hexdigest()



def fresh_url(url):
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query.append(('studio_check', str(time.time_ns())))
    return urllib.parse.urlunsplit(parsed._replace(query=urllib.parse.urlencode(query)))


def read_verified_release(settings, minimum_sequence=0, allow_loopback=False, cache_path=None):
    """Only a signed, non-rollback manifest may announce a new version.

    GitHub's Latest redirect can cache the previous release. A fresh request
    and an immutable tag discovered through the same public repository recover
    that condition without changing the publisher key or using credentials.
    """
    feed = validate_url(settings['feedUrl'], allow_loopback)

    def read(url):
        with open_url(fresh_url(url), {'Cache-Control': 'no-cache'},
                      allow_loopback=allow_loopback, timeout=12) as response:
            raw = response.read(256 * 1024 + 1)
        if len(raw) > 256 * 1024:
            raise ValueError('Manifest phát hành vượt giới hạn.')
        envelope = json.loads(raw)
        release = verify_envelope(envelope, settings['publicKeyPem'])
        if release['sequence'] < minimum_sequence:
            raise ValueError('Máy chủ trả bản phát hành cũ hơn bản đã xác minh.')
        if cache_path is not None:
            atomic_json(cache_path, envelope)
        return release

    try:
        return read(feed)
    except Exception as primary_error:
        parsed = urllib.parse.urlsplit(feed)
        match = re.fullmatch(r'/([A-Za-z0-9-]+/[A-Za-z0-9_.-]+)/releases/latest/download/latest\.json', parsed.path)
        if parsed.hostname != 'github.com' or parsed.port not in (None, 443) or not match:
            cached = cached_release(settings, cache_path, minimum_sequence)
            if cached is not None:
                return cached
            raise
        repo = match.group(1)
        try:
            with open_url(fresh_url('https://api.github.com/repos/' + repo + '/releases/latest'),
                          {'Cache-Control': 'no-cache'}, timeout=12) as response:
                raw = response.read(256 * 1024 + 1)
            if len(raw) > 256 * 1024:
                raise ValueError('Thông tin phát hành vượt giới hạn.')
            latest = json.loads(raw)
            tag = latest.get('tag_name', '')
            if latest.get('draft') or latest.get('prerelease') or not re.fullmatch(r'[A-Za-z0-9._-]+', tag):
                raise ValueError('Thông tin phát hành chưa hợp lệ.')
            return read('https://github.com/' + repo + '/releases/download/' + tag + '/latest.json')
        except Exception as fallback_error:
            cached = cached_release(settings, cache_path, minimum_sequence)
            if cached is not None:
                return cached
            raise ValueError('Chưa đọc được bản phát hành đã ký: ' + update_error(fallback_error)) from primary_error


def cached_release(settings, path, minimum_sequence=0):
    if path is None:
        return None
    try:
        path = Path(path)
        if not path.is_file() or path.stat().st_size > 256 * 1024:
            return None
        release = verify_envelope(read_json(path), settings['publicKeyPem'])
        return release if release['sequence'] >= minimum_sequence else None
    except Exception:
        # An unsigned, changed or rolled-back cache is never usable offline.
        return None


def update_error(error):
    if isinstance(error, urllib.error.HTTPError):
        return 'Máy chủ cập nhật trả HTTP ' + str(error.code) + '.'
    network = isinstance(error, (urllib.error.URLError, socket.gaierror, ConnectionError))
    cause = getattr(error, 'reason', error)
    code = getattr(cause, 'winerror', None) or getattr(cause, 'errno', None)
    if isinstance(cause, ssl.SSLCertVerificationError):
        return 'Windows chưa xác minh được chứng chỉ HTTPS của nơi phát hành.'
    if network:
        if isinstance(cause, TimeoutError):
            return 'Kết nối tới nơi phát hành hết thời gian chờ.'
        return 'Không kết nối được nơi phát hành' + (f' (mã {code}).' if code else '.')
    if isinstance(cause, TimeoutError):
        return str(cause).split('?')[0][:500] or 'Thao tác cập nhật hết thời gian; tiến độ đã được giữ.'
    if isinstance(cause, OSError):
        if code in (112, errno.ENOSPC):
            return 'Ổ đĩa không đủ chỗ ghi bản cập nhật; giữ nguyên bản đang dùng.'
        if code in (206, errno.ENAMETOOLONG):
            return 'Đường dẫn file cập nhật quá dài trên Windows (mã ' + str(code) + ').'
        if isinstance(cause, PermissionError) or code in (5, 32, 33):
            return 'Windows đang khóa file hoặc chưa cho phép ghi bản cập nhật' + (f' (mã {code}).' if code else '.')
        return 'Không đọc/ghi được file cập nhật trên ổ đĩa' + (f' (mã {code}).' if code else '.')
    return str(error).split('?')[0][:500]


def record_failure(root, error, transfer_failed=False):
    previous = status(root)
    # A transient check must not erase an already verified available release
    # or another worker's download progress. It never confirms "latest".
    keys = ('availableVersion', 'releaseNotes', 'downloadMB', 'downloadPercent',
            'pendingVersion', 'checkedAt', 'verificationPercent', 'verifiedFiles',
            'verificationFiles', 'transferUpdatedAt')
    saved = {key: previous[key] for key in keys if key in previous}
    phase = previous.get('remoteUpdatePhase')
    if transfer_failed or phase not in ('available', 'downloading', 'verifying', 'waiting-for-app-close'):
        phase = 'failed'
    if (Path(root)/'updates/pending.json').is_file():
        phase = 'waiting-for-app-close'
    cause = getattr(error, 'reason', error)
    saved.update(remoteUpdatePhase=phase, updateError=update_error(error),
                 updateErrorType=type(cause).__name__,
                 updateErrorCode=getattr(cause, 'winerror', None) or getattr(cause, 'errno', None),
                 checkFailedAt=utc())
    atomic_json(Path(root)/'updates'/'remote-status.json', saved)


def background_running(root):
    if os.name != 'nt':
        return False
    name = 'Local\\AIVideoStudioBackground' + hashlib.sha256(str(Path(root).resolve()).rstrip('\\').lower().encode('utf-8')).hexdigest().upper()
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenMutexW.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_wchar_p]
    kernel.OpenMutexW.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    kernel.ReleaseMutex.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    handle = kernel.OpenMutexW(0x100001, False, name)
    if not handle:
        return False
    try:
        waited = kernel.WaitForSingleObject(handle, 0)
        if waited in (0, 0x80):
            kernel.ReleaseMutex(handle)
            return False
        return waited == 258
    finally:
        kernel.CloseHandle(handle)


def transfer_in_progress(root):
    current = status(root)
    return (current.get('remoteUpdatePhase') in ('downloading', 'verifying')
            and background_running(root))


def _check(root, stage=False, allow_loopback=False):
    root = Path(root).resolve()
    settings = config(root)
    if not settings.get('feedUrl') or not settings.get('publicKeyPem'):
        return status(root)
    if (root / 'updates' / 'REMOTE_PAUSE').exists():
        return {**status(root), 'remoteUpdatePhase': 'paused'}
    updates = root / 'updates'
    updates.mkdir(exist_ok=True)
    pending_file = updates / 'pending.json'
    if pending_file.exists():
        pending = read_json(pending_file)
        return {**status(root), 'remoteUpdatePhase': 'waiting-for-app-close', 'pendingVersion': pending['version']}
    if not stage and transfer_in_progress(root):
        return status(root)
    info = read_json(root / 'installation.json')
    feed_url = validate_url(settings['feedUrl'], allow_loopback)
    state_file = updates / 'remote-state.json'
    state = read_json(state_file) if state_file.exists() else {}
    cache_path = updates / 'verified-release.json'
    release = cached_release(settings, cache_path, state.get('highestSeenSequence', 0)) if stage else None
    if release is not None:
        existing = updates / ('download-' + str(release['sequence']) + '.zip')
        if (release['sequence'] <= int(info.get('releaseSequence', 0)) or
                tuple(map(int, release['version'].split('.'))) < tuple(map(int, info['version'].split('.'))) or
                (not existing.is_file() and not existing.with_name(existing.name + '.partial').is_file())):
            release = None
    if release is None:
        release = read_verified_release(settings, state.get('highestSeenSequence', 0), allow_loopback, cache_path=cache_path)
    if not stage and transfer_in_progress(root):
        return status(root)
    current_sequence = int(info.get('releaseSequence', 0))
    current_version = tuple(map(int, info['version'].split('.')))
    new_version = tuple(map(int, release['version'].split('.')))
    # A local source build and its Internet ZIP use different publication times.
    # Do not download the developer PC's identical verified build again.
    current_manifest = root / info['current'] / 'package-manifest.json'
    source_fingerprint = release.get('sourceFingerprint', '')
    local_build = read_json(current_manifest) if current_manifest.is_file() else {}
    same_local_build = (new_version == current_version
                        and local_build.get('channel') == 'local'
                        and isinstance(source_fingerprint, str) and len(source_fingerprint) == 64
                        and all(c in '0123456789abcdef' for c in source_fingerprint)
                        and local_build.get('sourceFingerprint') == source_fingerprint)
    if new_version < current_version or same_local_build or (new_version == current_version and release['sequence'] <= current_sequence):
        atomic_json(state_file, {'highestSeenSequence': max(release['sequence'], state.get('highestSeenSequence', 0))})
        atomic_json(updates / 'remote-status.json', {'remoteUpdatePhase': 'up-to-date', 'checkedAt': utc()})
        return status(root)
    atomic_json(state_file, {'highestSeenSequence': max(release['sequence'], state.get('highestSeenSequence', 0))})
    available = {'remoteUpdatePhase': 'available', 'availableVersion': release['version'], 'releaseNotes': release.get('notes', ''), 'downloadMB': round(release['package']['bytes'] / 1024**2, 1), 'checkedAt': utc()}
    atomic_json(updates / 'remote-status.json', available)
    if not stage:
        return status(root)
    with stage_lock():
        if pending_file.exists():
            return status(root)
        size = release['package']['bytes']
        required_space = size + int(release['package'].get('uncompressedBytes', MAX_EXTRACTED)) + 512 * 1024**2
        if shutil.disk_usage(root).free < required_space:
            raise ValueError('Không đủ dung lượng chuẩn bị bản cập nhật; app hiện tại được giữ.')
        package_url = urllib.parse.urljoin(feed_url, release['package']['url'])
        validate_url(package_url, allow_loopback)
        archive = updates / ('download-' + str(release['sequence']) + '.zip')
        for obsolete in updates.glob('download-*'):
            if obsolete.name not in (archive.name, archive.name + '.partial') and obsolete.is_file() and not obsolete.is_symlink():
                obsolete.unlink()
        progress_time = [0.0]

        def progress(received, total):
            if time.monotonic() - progress_time[0] >= 1 or received == total:
                progress_time[0] = time.monotonic()
                atomic_json(updates / 'remote-status.json', {**available, 'remoteUpdatePhase': 'downloading', 'downloadPercent': round(received * 100 / total), 'transferUpdatedAt': utc()})

        download(package_url, archive, size, release['package']['sha256'], progress, allow_loopback)
        staging_file = updates / 'staging.json'
        staging = read_json(staging_file) if staging_file.is_file() else {}
        prefix = release['version'] + '_' + str(release['sequence']) + '_'
        destination = None
        if (staging.get('releaseSequence') == release['sequence'] and
                staging.get('packageSha256') == release['package']['sha256']):
            relative = staging.get('candidate', '')
            if re.fullmatch(r'versions/' + re.escape(prefix) + r'[0-9a-f]{6}', relative):
                candidate = child(root, relative)
                protected = {str((root / info[k]).resolve()).casefold() for k in ('current', 'previous') if info.get(k)}
                if str(candidate.resolve()).casefold() not in protected:
                    destination = candidate
        if destination is None:
            destination = child(root / 'versions', prefix + uuid.uuid4().hex[:6])
        destination.mkdir(parents=True, exist_ok=True)
        atomic_json(staging_file, {'schemaVersion': 1, 'releaseSequence': release['sequence'],
            'packageSha256': release['package']['sha256'], 'candidate': destination.relative_to(root).as_posix()})
        try:
            progress_time[0] = 0
            def verification(done, total, files, count):
                if time.monotonic() - progress_time[0] >= 1 or files == count:
                    progress_time[0] = time.monotonic()
                    atomic_json(updates / 'remote-status.json', {
                        **available, 'remoteUpdatePhase': 'verifying',
                        'verificationPercent': round(done * 100 / max(total, 1)),
                        'verifiedFiles': files, 'verificationFiles': count,
                        'transferUpdatedAt': utc()})
            manifest_sha = extract_verified(archive, destination, release, verification, resume=True)
            request = {'version': release['version'], 'candidate': destination.relative_to(root).as_posix(), 'manifestSha256': manifest_sha, 'sourceFingerprint': release.get('sourceFingerprint', 'published-release'), 'releaseSequence': release['sequence'], 'origin': 'remote', 'at': utc()}
            atomic_json(pending_file, request)
            # Pending is the commit point. A status-file lock or cleanup error
            # must never delete a fully verified update waiting for activation.
            try:
                atomic_json(updates / 'remote-status.json', {**available, 'remoteUpdatePhase': 'waiting-for-app-close', 'pendingVersion': release['version']})
            except OSError:
                pass
            try:
                staging_file.unlink(missing_ok=True)
                archive.unlink(missing_ok=True)
            except OSError:
                pass
        except (OSError, TimeoutError):
            # Preserve signed archive + partial candidate. Next run verifies
            # existing files and only extracts missing or changed ones.
            raise
        except Exception:
            # Remove only this exact generated candidate on integrity failure.
            if not pending_file.exists():
                if destination.exists() and not destination.is_symlink() and not destination.is_junction():
                    shutil.rmtree(destination)
                staging_file.unlink(missing_ok=True)
            raise
    return status(root)


def check(root, stage=False, allow_loopback=False):
    try:
        return _check(root, stage, allow_loopback)
    except Exception as error:
        record_failure(root, error, transfer_failed=stage)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['status', 'check', 'stage', 'configure', 'pause', 'resume'])
    parser.add_argument('--root')
    parser.add_argument('--feed-url')
    args = parser.parse_args()
    root = Path(args.root) if args.root else locate_installation()
    if root is None:
        return {'releaseFeedConfigured': False, 'remoteUpdatePhase': 'development-not-installed'}
    if args.operation == 'configure':
        set_feed(root, args.feed_url)
    elif args.operation in ('pause', 'resume'):
        marker = root / 'updates' / 'REMOTE_PAUSE'
        if args.operation == 'pause':
            marker.parent.mkdir(exist_ok=True)
            marker.write_text('paused by user', 'utf-8')
        else:
            marker.unlink(missing_ok=True)
    elif args.operation in ('check', 'stage'):
        try:
            return check(root, args.operation == 'stage')
        except Exception as error:
            raise
    return status(root)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    try:
        print(json.dumps(main(), ensure_ascii=False))
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
