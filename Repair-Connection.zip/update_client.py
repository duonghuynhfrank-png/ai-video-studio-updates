"""Verify publisher signatures, notify, and stage app updates without reinstalling."""
import argparse
import base64
import contextlib
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import urllib.parse
import uuid
import zipfile
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from release_io import atomic_json, child, digest, download, open_url, read_json, validate_url

MAX_PACKAGE = 2 * 1024**3
MAX_EXTRACTED = 4 * 1024**3


def locate_installation():
    for parent in Path(__file__).resolve().parents:
        if (parent / 'installation.json').is_file():
            return parent
        if (parent / 'App' / 'installation.json').is_file():
            return parent / 'App'
    return None


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def config(root):
    root = Path(root)
    trust_file = root / 'update-trust.json'
    if not trust_file.is_file():
        return {}
    result = read_json(trust_file)
    settings_file = root / 'updates' / 'client.json'
    if settings_file.is_file():
        settings = read_json(settings_file)
        # Endpoint is editable. The public key remains pinned to this publisher.
        result['feedUrl'] = settings.get('feedUrl', result.get('feedUrl', ''))
    return result


def set_feed(root, url):
    validate_url(url)
    trust = config(root)
    if not trust.get('publicKeyPem'):
        raise ValueError('Bản app chưa có khóa xác minh của nhà phát hành.')
    atomic_json(Path(root) / 'updates' / 'client.json', {'schemaVersion': 1, 'feedUrl': url})


def verify_envelope(envelope, public_key):
    if envelope.get('algorithm') != 'RSA-PSS-SHA256':
        raise ValueError('Chữ ký bản phát hành không được hỗ trợ.')
    encoded = base64.b64decode(envelope['payload'], validate=True)
    signature = base64.b64decode(envelope['signature'], validate=True)
    key = serialization.load_pem_public_key(public_key.encode('ascii'))
    if not isinstance(key, rsa.RSAPublicKey) or key.key_size < 3072:
        raise ValueError('Khóa nhà phát hành không hợp lệ.')
    key.verify(signature, encoded, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32), hashes.SHA256())
    release = json.loads(encoded)
    if release.get('schemaVersion') != 1 or release.get('target') != 'windows-x64' or release.get('applicationId') != 'vn.aivideostudio':
        raise ValueError('Bản phát hành không dành cho ứng dụng này.')
    if not isinstance(release.get('sequence'), int) or release['sequence'] <= 0:
        raise ValueError('Thứ tự bản phát hành không hợp lệ.')
    parts = release.get('version', '').split('.')
    if len(parts) != 3 or any(not p.isdigit() for p in parts):
        raise ValueError('Phiên bản không hợp lệ.')
    package = release['package']
    if not isinstance(package.get('bytes'), int) or not 0 < package['bytes'] <= MAX_PACKAGE:
        raise ValueError('Gói cập nhật vượt giới hạn cho phép.')
    if len(package.get('sha256', '')) != 64 or any(c not in '0123456789abcdef' for c in package['sha256']):
        raise ValueError('Checksum gói cập nhật không hợp lệ.')
    return release


def status(root):
    root = Path(root)
    settings = config(root)
    result = {'releaseFeedConfigured': bool(settings.get('feedUrl') and settings.get('publicKeyPem')), 'releaseFeedUrl': settings.get('feedUrl', ''), 'remoteUpdatePhase': 'not-configured', 'automaticRemoteUpdates': not (root / 'updates' / 'REMOTE_PAUSE').exists()}
    status_file = root / 'updates' / 'remote-status.json'
    if status_file.exists():
        result.update(read_json(status_file))
    return result


@contextlib.contextmanager
def stage_lock():
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    kernel.CreateMutexW.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    kernel.ReleaseMutex.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    handle = kernel.CreateMutexW(None, False, 'Local\\AIVideoStudioLocalPublish')
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    acquired = kernel.WaitForSingleObject(handle, 0) in (0, 0x80)
    try:
        if not acquired:
            raise ValueError('Một bản cập nhật khác đang được chuẩn bị. Hãy thử lại sau.')
        yield
    finally:
        if acquired:
            kernel.ReleaseMutex(handle)
        kernel.CloseHandle(handle)


def extract_verified(archive, destination, release):
    with zipfile.ZipFile(archive) as source:
        entries = source.infolist()
        if len(entries) > 30000 or sum(item.file_size for item in entries) > MAX_EXTRACTED:
            raise ValueError('Gói cập nhật có cấu trúc quá lớn.')
        seen = set()
        for item in entries:
            path = item.filename.rstrip('/')
            if not path:
                continue
            key = path.replace('\\', '/').casefold()
            if key in seen or ((item.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError('Gói cập nhật có file trùng hoặc liên kết.')
            seen.add(key)
            target = child(destination, path)
            if path.split('/')[0].lower() == 'models':
                raise ValueError('Gói cập nhật app không được ghi đè kho model.')
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with source.open(item) as incoming, target.open('xb') as output:
                shutil.copyfileobj(incoming, output, 1024 * 1024)
    manifest_path = Path(destination) / 'package-manifest.json'
    manifest = read_json(manifest_path)
    if manifest.get('schemaVersion') != 1 or manifest.get('version') != release['version'] or manifest.get('target') != 'windows-x64':
        raise ValueError('Manifest không khớp bản phát hành đã ký.')
    required = {'ai_video_studio.exe', 'flutter_windows.dll', 'data/app.so', '.installed', 'maintenance/Launch.ps1', 'maintenance/Update.Common.ps1', 'maintenance/Uninstall.ps1', 'maintenance/Rollback.ps1'}
    required = {name.casefold() for name in required}
    recorded = set()
    for file in manifest['files']:
        path = file['path'].replace('\\', '/')
        if path.casefold() in recorded:
            raise ValueError('Manifest có đường dẫn trùng.')
        recorded.add(path.casefold())
        target = child(destination, path)
        if not target.is_file() or target.stat().st_size != file['bytes'] or digest(target) != file['sha256']:
            raise ValueError('File cập nhật sai checksum: ' + path)
    actual = {p.relative_to(destination).as_posix().casefold() for p in Path(destination).rglob('*') if p.is_file() and p.name != 'package-manifest.json'}
    if not required.issubset(recorded) or recorded != actual:
        raise ValueError('Manifest không mô tả đầy đủ các file cập nhật.')
    return digest(manifest_path)


def check(root, stage=False, allow_loopback=False):
    root = Path(root).resolve()
    settings = config(root)
    if not settings.get('feedUrl') or not settings.get('publicKeyPem'):
        return status(root)
    if (root / 'updates' / 'REMOTE_PAUSE').exists():
        return {**status(root), 'remoteUpdatePhase': 'paused'}
    updates = root / 'updates'
    updates.mkdir(exist_ok=True)
    pending_file = updates / 'pending.json'
    if pending_file.exists():
        pending = read_json(pending_file)
        return {**status(root), 'remoteUpdatePhase': 'waiting-for-app-close', 'pendingVersion': pending['version']}
    info = read_json(root / 'installation.json')
    feed_url = validate_url(settings['feedUrl'], allow_loopback)
    with open_url(feed_url, allow_loopback=allow_loopback) as response:
        encoded = response.read(256 * 1024 + 1)
    if len(encoded) > 256 * 1024:
        raise ValueError('Manifest phát hành vượt giới hạn.')
    release = verify_envelope(json.loads(encoded), settings['publicKeyPem'])
    state_file = updates / 'remote-state.json'
    state = read_json(state_file) if state_file.exists() else {}
    if release['sequence'] < state.get('highestSeenSequence', 0):
        raise ValueError('Máy chủ trả bản phát hành cũ hơn bản đã xác minh.')
    current_sequence = int(info.get('releaseSequence', 0))
    current_version = tuple(map(int, info['version'].split('.')))
    new_version = tuple(map(int, release['version'].split('.')))
    # A local source build and its Internet ZIP use different publication times.
    # Do not download the developer PC's identical verified build again.
    current_manifest = root / info['current'] / 'package-manifest.json'
    source_fingerprint = release.get('sourceFingerprint', '')
    local_build = read_json(current_manifest) if current_manifest.is_file() else {}
    same_local_build = (new_version == current_version
                        and local_build.get('channel') == 'local'
                        and isinstance(source_fingerprint, str) and len(source_fingerprint) == 64
                        and all(c in '0123456789abcdef' for c in source_fingerprint)
                        and local_build.get('sourceFingerprint') == source_fingerprint)
    if new_version < current_version or same_local_build or (new_version == current_version and release['sequence'] <= current_sequence):
        atomic_json(state_file, {'highestSeenSequence': max(release['sequence'], state.get('highestSeenSequence', 0))})
        atomic_json(updates / 'remote-status.json', {'remoteUpdatePhase': 'up-to-date', 'checkedAt': utc()})
        return status(root)
    atomic_json(state_file, {'highestSeenSequence': max(release['sequence'], state.get('highestSeenSequence', 0))})
    available = {'remoteUpdatePhase': 'available', 'availableVersion': release['version'], 'releaseNotes': release.get('notes', ''), 'downloadMB': round(release['package']['bytes'] / 1024**2, 1), 'checkedAt': utc()}
    atomic_json(updates / 'remote-status.json', available)
    if not stage:
        return status(root)
    with stage_lock():
        if pending_file.exists():
            return status(root)
        size = release['package']['bytes']
        required_space = size + int(release['package'].get('uncompressedBytes', MAX_EXTRACTED)) + 512 * 1024**2
        if shutil.disk_usage(root).free < required_space:
            raise ValueError('Không đủ dung lượng chuẩn bị bản cập nhật; app hiện tại được giữ.')
        package_url = urllib.parse.urljoin(feed_url, release['package']['url'])
        validate_url(package_url, allow_loopback)
        archive = updates / ('download-' + str(release['sequence']) + '.zip')
        for obsolete in updates.glob('download-*'):
            if obsolete.name not in (archive.name, archive.name + '.partial') and obsolete.is_file() and not obsolete.is_symlink():
                obsolete.unlink()
        progress_time = [0.0]

        def progress(received, total):
            if time.monotonic() - progress_time[0] >= 1 or received == total:
                progress_time[0] = time.monotonic()
                atomic_json(updates / 'remote-status.json', {**available, 'remoteUpdatePhase': 'downloading', 'downloadPercent': round(received * 100 / total)})

        download(package_url, archive, size, release['package']['sha256'], progress, allow_loopback)
        destination = child(root / 'versions', release['version'] + '_' + str(release['sequence']) + '_' + uuid.uuid4().hex[:6])
        destination.mkdir(parents=True)
        try:
            atomic_json(updates / 'remote-status.json', {**available, 'remoteUpdatePhase': 'verifying'})
            manifest_sha = extract_verified(archive, destination, release)
            request = {'version': release['version'], 'candidate': destination.relative_to(root).as_posix(), 'manifestSha256': manifest_sha, 'sourceFingerprint': release.get('sourceFingerprint', 'published-release'), 'releaseSequence': release['sequence'], 'origin': 'remote', 'at': utc()}
            atomic_json(pending_file, request)
            atomic_json(updates / 'remote-status.json', {**available, 'remoteUpdatePhase': 'waiting-for-app-close', 'pendingVersion': release['version']})
            archive.unlink(missing_ok=True)
        except Exception:
            # Newly created, validated child only; never remove an existing app version.
            if destination.exists() and not destination.is_symlink() and not destination.is_junction():
                shutil.rmtree(destination)
            raise
    return status(root)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['status', 'check', 'stage', 'configure', 'pause', 'resume'])
    parser.add_argument('--root')
    parser.add_argument('--feed-url')
    args = parser.parse_args()
    root = Path(args.root) if args.root else locate_installation()
    if root is None:
        return {'releaseFeedConfigured': False, 'remoteUpdatePhase': 'development-not-installed'}
    if args.operation == 'configure':
        set_feed(root, args.feed_url)
    elif args.operation in ('pause', 'resume'):
        marker = root / 'updates' / 'REMOTE_PAUSE'
        if args.operation == 'pause':
            marker.parent.mkdir(exist_ok=True)
            marker.write_text('paused by user', 'utf-8')
        else:
            marker.unlink(missing_ok=True)
    elif args.operation in ('check', 'stage'):
        try:
            return check(root, args.operation == 'stage')
        except Exception as error:
            atomic_json(root / 'updates' / 'remote-status.json', {'remoteUpdatePhase': 'failed', 'updateError': str(error), 'checkedAt': utc()})
            raise
    return status(root)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    try:
        print(json.dumps(main(), ensure_ascii=False))
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
