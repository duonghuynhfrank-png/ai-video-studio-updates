"""Public connection diagnostics; no credentials, session tokens or user media read."""
import argparse
import hashlib
import json
from pathlib import Path
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import uuid

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import update_client
from release_io import child, read_json, open_url

FEED = 'https://github.com/duonghuynhfrank-png/ai-video-studio-updates/releases/latest/download/latest.json'
ACCOUNT = 'https://ai-video-studio-accounts.ai-video-studio-account-service.workers.dev'
SERVER_ID = 'srv_b132ba46e46647aebe6c246924b9ab05'

def describe(error):
    cause = getattr(error, 'reason', error)
    network = isinstance(error, (urllib.error.URLError, urllib.error.HTTPError))
    return {'type': 'network' if network else type(cause).__name__,
            'osCode': getattr(cause, 'winerror', None) or getattr(cause, 'errno', None),
            'message': update_client.update_error(error)}


def seed_recovery_release(root, trust):
    bundled = HERE / 'publisher-latest.json'
    state = root / 'updates/remote-state.json'
    minimum = read_json(state).get('highestSeenSequence', 0) if state.is_file() else 0
    release = update_client.cached_release(trust, bundled, minimum)
    target = root / 'updates/verified-release.json'
    existing = update_client.cached_release(trust, target, minimum)
    if release is not None and (existing is None or release['sequence'] > existing['sequence']):
        # The bootstrap carries the publisher's signed envelope, never an
        # unsigned instruction to trust a ZIP or change the publisher key.
        update_client.atomic_json(target, read_json(bundled))
    return update_client.cached_release(trust, target, minimum)


def recover_incomplete_pending(root):
    pending = root / 'updates/pending.json'
    if not pending.is_file():
        return False
    request = read_json(pending)
    relative = str(request.get('candidate', '')).replace('\\', '/')
    if not relative.startswith('versions/'):
        raise ValueError('Đường dẫn bản đang chờ không nằm trong thư mục phiên bản.')
    candidate = child(root, relative)
    manifest = candidate / 'package-manifest.json'
    valid = (manifest.is_file() and hashlib.sha256(manifest.read_bytes()).hexdigest() == request.get('manifestSha256'))
    if valid:
        return False
    # Older receivers could commit pending, then delete its candidate after a
    # status-file error. Preserve the receipt for diagnostics, not an endless
    # wait for a candidate that no longer exists. Never remove app/Data files.
    backup = root / 'updates' / ('pending-incomplete-' + uuid.uuid4().hex + '.json')
    pending.replace(backup)
    print('Đã giữ lại nhật ký bản chờ bị thiếu file; chuẩn bị lại bản có chữ ký.', flush=True)
    return True


def validate_root(root):
    root = Path(root).absolute()
    cursor = root
    while cursor != cursor.parent:
        if cursor.is_symlink() or cursor.is_junction():
            raise ValueError('Không sửa cấu hình qua thư mục liên kết.')
        cursor = cursor.parent
    info = read_json(root / 'installation.json')
    trust = read_json(root / 'update-trust.json')
    expected = read_json(HERE / 'publisher-trust.json')
    if trust.get('applicationId') != 'vn.aivideostudio' or ''.join(trust.get('publicKeyPem', '').split()) != ''.join(expected['publicKeyPem'].split()):
        raise ValueError('Khóa nhà phát hành không khớp; giữ nguyên phần mềm.')
    current = Path(info['current'])
    if current.is_absolute():
        if current.parent.name != 'versions':
            raise ValueError('Thư mục phiên bản chưa hợp lệ.')
        current = Path('versions') / current.name
    version = child(root, current.as_posix())
    if not version.is_relative_to(root / 'versions') or not (version / 'ai_video_studio.exe').is_file():
        raise ValueError('Thiếu file app trong phiên bản đã cài.')
    return root, info, trust, version

def probe_accounts():
    with open_url(ACCOUNT + '/v1/accounts/capabilities', timeout=8) as response:
        value = json.loads(response.read(8193))
    if value.get('serverId') != SERVER_ID or value.get('schemaVersion') != 2 or not value.get('passwordLogin'):
        raise ValueError('Máy chủ tài khoản chưa trả đúng thông tin; giữ Data tại máy.')
    return {'reachable': True, 'passwordLogin': True, 'projectSync': value.get('projectSync') is True}

def probe_release(trust):
    with open_url(FEED) as response:
        raw = response.read(256 * 1024 + 1)
    if len(raw) > 256 * 1024:
        raise ValueError('Manifest phát hành vượt giới hạn.')
    release = update_client.verify_envelope(json.loads(raw), trust['publicKeyPem'])
    # Check access to the actual package, rather than only its manifest.
    package_url = urllib.parse.urljoin(FEED, release.get('changes', release['package'])['url'])
    with open_url(package_url, {'Range': 'bytes=0-255'}) as response:
        first = response.read(256)
        if len(first) != 256 or first[:2] != b'PK':
            raise ValueError('Đường tải gói cập nhật chưa trả đúng file ZIP.')
    return release

def progress(root, stop):
    previous = None
    while not stop.wait(2):
        try:
            status = read_json(root / 'updates/remote-status.json')
            phase = status.get('remoteUpdatePhase')
            percent = status.get('verificationPercent') if phase == 'verifying' else status.get('downloadPercent')
            message = (phase, percent)
            if message == previous:
                continue
            previous = message
            if phase == 'downloading':
                label = 'phần thay đổi' if status.get('updatePackageType') == 'changes' else 'bản cập nhật'
                print(f'Đang tải {label} {status.get("availableVersion", "")}: {percent or 0}% · {status.get("downloadMB", "…")} MB', flush=True)
            elif phase == 'verifying':
                label = 'Kiểm tra và dùng lại thư viện' if status.get('updatePackageType') == 'changes' else 'Giải nén và kiểm tra'
                print(f'{label}: {percent or 0}% · {status.get("verifiedFiles", 0)}/{status.get("verificationFiles", "…")} file', flush=True)
        except (OSError, ValueError):
            pass

def run(root, stage=False, account_probe=probe_accounts, release_probe=probe_release):
    root, info, trust, version = validate_root(root)
    report = {'installedVersion': info['version'], 'paidServicesAdded': False,
              'userDataRead': False, 'userDataModified': False, 'diagnosticSchema': 1}
    provider_file = version / 'python/studio-account-provider.json'
    provider = read_json(provider_file) if provider_file.is_file() else {}
    report['installedAccountEndpoint'] = ('current-https' if provider.get('serverUrl') == ACCOUNT
        else 'old-local-server' if str(provider.get('serverUrl', '')).startswith('http://127.0.0.1')
        else 'missing-or-other')
    try:
        report['accounts'] = account_probe()
        print('Máy chủ tài khoản đã phản hồi HTTPS.', flush=True)
    except Exception as error:
        report['accounts'] = {'reachable': False, 'error': describe(error)}
        print(report['accounts']['error']['message'], flush=True)
    try:
        report['stalePendingRecovered'] = recover_incomplete_pending(root) if stage else False
        cached = seed_recovery_release(root, trust)
        archive = root / 'updates' / ('download-' + str(cached['sequence']) + ('-changes' if 'changes' in cached else '') + '.zip') if cached else None
        if stage and archive is not None and archive.is_file():
            release = cached
            print('Đã có gói tải và chữ ký đã xác minh. Dùng lại gói này, không cần kết nối lại để giải nén.', flush=True)
        else:
            release = release_probe(trust)
        cached_available = bool(stage and archive is not None and archive.is_file())
        report['updates'] = {'reachable': not cached_available, 'signatureVerified': True, 'packageAccessible': True,
            'latestVersion': release['version'], 'packageBytes': release.get('changes', release['package'])['bytes'],
            'packageType': 'changes' if 'changes' in release else 'full',
            'cachedPackageUsed': cached_available, 'canResume': cached_available}
        print(f'Bản có chữ ký đã xác minh: {release["version"]}. ' +
              ('Gói đã có trên máy.' if cached_available else 'Gói tải truy cập được.'), flush=True)
    except Exception as error:
        report['updates'] = {'reachable': False, 'error': describe(error)}
        print(report['updates']['error']['message'], flush=True)
    if stage and (report['updates']['reachable'] or report['updates'].get('canResume')):
        print('Đang tải và xác minh bản mới nhất; tiến độ sẽ hiện bên dưới.', flush=True)
        update_client.set_feed(root, FEED)
        (root / 'updates/REMOTE_PAUSE').unlink(missing_ok=True)
        stop = threading.Event()
        monitor = threading.Thread(target=progress, args=(root, stop), daemon=True)
        monitor.start()
        try:
            result = update_client.check(root, stage=True)
            report['staging'] = {key: result[key] for key in ('remoteUpdatePhase', 'pendingVersion', 'availableVersion',
                'updatePackageType', 'downloadMB', 'reusedFiles', 'reusedBytes', 'changedFiles', 'writtenBytes') if key in result}
            if result.get('pendingVersion'):
                print(f'Đã chuẩn bị bản {result["pendingVersion"]}. Lưu công việc và đóng/mở app để áp dụng.', flush=True)
            else:
                print('Bản đã cài khớp bản phát hành. Không cần tải lại.', flush=True)
        except Exception as error:
            report['staging'] = {'remoteUpdatePhase': 'failed', 'error': describe(error)}
            print(report['staging']['error']['message'], flush=True)
        finally:
            stop.set()
            monitor.join(3)
    return report

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    parser.add_argument('--stage', action='store_true')
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    if args.preflight:
        root, info, trust, version = validate_root(args.root)
        release = seed_recovery_release(root, trust)
        newer = (release is not None and 'changes' in release and
            tuple(map(int, release['version'].split('.'))) > tuple(map(int, info['version'].split('.'))) and
            release['sequence'] > int(info.get('releaseSequence', 0)))
        print(json.dumps({'canReplaceTransfer': newer and not (root / 'updates/pending.json').exists()}))
        return
    try:
        report = run(args.root, args.stage)
    except Exception as error:
        report = {'diagnosticSchema': 1, 'failed': True, 'error': describe(error), 'userDataModified': False}
        print(report['error']['message'], flush=True)
    Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), 'utf-8')
    update_failed = report.get('staging', {}).get('remoteUpdatePhase') == 'failed'
    failure = report.get('failed') or not (report.get('updates', {}).get('reachable') or report.get('updates', {}).get('canResume')) or update_failed
    if not args.stage:
        failure = failure or not report.get('accounts', {}).get('reachable')
    raise SystemExit(1 if failure else 0)

if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    main()
