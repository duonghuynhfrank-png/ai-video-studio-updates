"""Public connection diagnostics; no credentials, session tokens or user media read."""
import argparse
import json
from pathlib import Path
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import update_client
from release_io import child, read_json, open_url

FEED = 'https://github.com/duonghuynhfrank-png/ai-video-studio-updates/releases/latest/download/latest.json'
ACCOUNT = 'https://ai-video-studio-accounts.ai-video-studio-account-service.workers.dev'
SERVER_ID = 'srv_b132ba46e46647aebe6c246924b9ab05'

def describe(error):
    if isinstance(error, urllib.error.HTTPError):
        return {'type': 'http', 'status': error.code, 'message': f'Máy chủ trả HTTP {error.code}.'}
    cause = getattr(error, 'reason', error)
    if isinstance(cause, ssl.SSLCertVerificationError):
        return {'type': 'tls', 'message': 'Windows/Python chưa xác minh được chứng chỉ HTTPS. Không bỏ kiểm tra chứng chỉ.'}
    if isinstance(cause, TimeoutError):
        return {'type': 'timeout', 'message': 'Kết nối hết thời gian chờ.'}
    if isinstance(cause, OSError):
        code = getattr(cause, 'winerror', None) or getattr(cause, 'errno', None)
        return {'type': 'network', 'osCode': code, 'message': 'Lỗi mạng hoặc DNS trên máy này.'}
    # Never include redirect URLs or authentication headers in a diagnostic.
    return {'type': type(error).__name__, 'message': str(error).split('?')[0][:300]}

def validate_root(root):
    root = Path(root).absolute()
    cursor = root
    while cursor != cursor.parent:
        if cursor.is_symlink() or cursor.is_junction():
            raise ValueError('Không sửa cấu hình qua thư mục liên kết.')
        cursor = cursor.parent
    info = read_json(root / 'installation.json')
    trust = read_json(root / 'update-trust.json')
    expected = read_json(HERE / 'publisher-trust.json')
    if trust.get('applicationId') != 'vn.aivideostudio' or ''.join(trust.get('publicKeyPem', '').split()) != ''.join(expected['publicKeyPem'].split()):
        raise ValueError('Khóa nhà phát hành không khớp; giữ nguyên phần mềm.')
    current = Path(info['current'])
    if current.is_absolute():
        if current.parent.name != 'versions':
            raise ValueError('Thư mục phiên bản chưa hợp lệ.')
        current = Path('versions') / current.name
    version = child(root, current.as_posix())
    if not version.is_relative_to(root / 'versions') or not (version / 'ai_video_studio.exe').is_file():
        raise ValueError('Thiếu file app trong phiên bản đã cài.')
    return root, info, trust, version

def probe_accounts():
    with open_url(ACCOUNT + '/v1/accounts/capabilities') as response:
        value = json.loads(response.read(8193))
    if value.get('serverId') != SERVER_ID or value.get('schemaVersion') != 2 or not value.get('passwordLogin'):
        raise ValueError('Máy chủ tài khoản chưa trả đúng thông tin; giữ Data tại máy.')
    return {'reachable': True, 'passwordLogin': True, 'projectSync': value.get('projectSync') is True}

def probe_release(trust):
    release = update_client.read_verified_release({**trust, 'feedUrl': FEED})
    # Check access to the actual package, rather than only its manifest.
    package_url = urllib.parse.urljoin(FEED, release['package']['url'])
    with open_url(package_url, {'Range': 'bytes=0-255'}) as response:
        first = response.read(256)
        if len(first) != 256 or first[:2] != b'PK':
            raise ValueError('Đường tải gói cập nhật chưa trả đúng file ZIP.')
    return release

def progress(root, stop):
    previous = None
    while not stop.wait(2):
        try:
            status = read_json(root / 'updates/remote-status.json')
            phase, percent = status.get('remoteUpdatePhase'), status.get('downloadPercent')
            message = (phase, percent)
            if message == previous:
                continue
            previous = message
            if phase == 'downloading':
                print(f'Đang tải bản {status.get("availableVersion", "")}: {percent or 0}%', flush=True)
            elif phase == 'verifying':
                print('Đã tải; đang giải nén và xác minh từng file…', flush=True)
        except (OSError, ValueError):
            pass

def run(root, stage=False, account_probe=probe_accounts, release_probe=probe_release):
    root, info, trust, version = validate_root(root)
    report = {'installedVersion': info['version'], 'paidServicesAdded': False,
              'userDataRead': False, 'userDataModified': False, 'diagnosticSchema': 1}
    provider_file = version / 'python/studio-account-provider.json'
    provider = read_json(provider_file) if provider_file.is_file() else {}
    report['installedAccountEndpoint'] = ('current-https' if provider.get('serverUrl') == ACCOUNT
        else 'old-local-server' if str(provider.get('serverUrl', '')).startswith('http://127.0.0.1')
        else 'missing-or-other')
    try:
        report['accounts'] = account_probe()
        print('Máy chủ tài khoản đã phản hồi HTTPS.', flush=True)
    except Exception as error:
        report['accounts'] = {'reachable': False, 'error': describe(error)}
        print(report['accounts']['error']['message'], flush=True)
    try:
        release = release_probe(trust)
        report['updates'] = {'reachable': True, 'signatureVerified': True, 'packageAccessible': True,
            'latestVersion': release['version'], 'packageBytes': release['package']['bytes']}
        print(f'Bản đã ký trên Internet: {release["version"]}. Gói tải truy cập được.', flush=True)
    except Exception as error:
        report['updates'] = {'reachable': False, 'error': describe(error)}
        print(report['updates']['error']['message'], flush=True)
    if stage and report['updates']['reachable']:
        print('Đang tải và xác minh bản mới nhất; tiến độ sẽ hiện bên dưới.', flush=True)
        update_client.set_feed(root, FEED)
        (root / 'updates/REMOTE_PAUSE').unlink(missing_ok=True)
        stop = threading.Event()
        monitor = threading.Thread(target=progress, args=(root, stop), daemon=True)
        monitor.start()
        try:
            result = update_client.check(root, stage=True)
            report['staging'] = {key: result[key] for key in ('remoteUpdatePhase', 'pendingVersion', 'availableVersion') if key in result}
            if result.get('pendingVersion'):
                print(f'Đã chuẩn bị bản {result["pendingVersion"]}. Lưu công việc và đóng/mở app để áp dụng.', flush=True)
            else:
                print('Bản đã cài khớp bản phát hành. Không cần tải lại.', flush=True)
        except Exception as error:
            report['staging'] = {'remoteUpdatePhase': 'failed', 'error': describe(error)}
            print(report['staging']['error']['message'], flush=True)
        finally:
            stop.set()
            monitor.join(3)
    return report

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    parser.add_argument('--stage', action='store_true')
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    try:
        report = run(args.root, args.stage)
    except Exception as error:
        report = {'diagnosticSchema': 1, 'failed': True, 'error': describe(error), 'userDataModified': False}
        print(report['error']['message'], flush=True)
    Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), 'utf-8')
    failure = report.get('failed') or not report.get('accounts', {}).get('reachable') or not report.get('updates', {}).get('reachable') or report.get('staging', {}).get('remoteUpdatePhase') == 'failed'
    raise SystemExit(1 if failure else 0)

if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    main()
