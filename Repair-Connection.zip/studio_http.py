"""Bounded account/Data reads with one safe retry and credential-free errors."""
import http.client
import json
import socket
import ssl
import time
import urllib.error
import urllib.request
from account_client import AccountError, NoRedirect


def failure(error):
    if isinstance(error, AccountError):
        return error
    reason = getattr(error, 'reason', error)
    code = getattr(reason, 'winerror', None) or getattr(reason, 'errno', None)
    status = error.code if isinstance(error, urllib.error.HTTPError) else None
    retryable = True
    if status is not None:
        kind, message = 'http', f'Dịch vụ tài khoản trả HTTP {status}.'
        retryable = status in (500, 502, 503, 504)
        try:
            body = json.loads(error.read(8193))
            if isinstance(body.get('message'), str):
                message = body['message'][:500] + f' (HTTP {status})'
        except Exception:
            pass
    elif isinstance(reason, ssl.SSLCertVerificationError):
        kind, retryable = 'tls', False
        message = 'Windows chưa xác minh được chứng chỉ HTTPS của dịch vụ tài khoản. Kiểm tra ngày giờ và chứng chỉ trên máy.'
    elif isinstance(reason, (TimeoutError, socket.timeout)):
        kind, message = 'timeout', 'Kết nối dịch vụ tài khoản hết thời gian chờ.'
    elif isinstance(reason, socket.gaierror):
        kind, message = 'dns', 'PC chưa tìm được địa chỉ dịch vụ tài khoản (DNS).'
    elif isinstance(reason, (http.client.IncompleteRead, http.client.RemoteDisconnected)):
        kind, message = 'interrupted', 'Phản hồi từ dịch vụ tài khoản bị gián đoạn.'
    elif isinstance(reason, OSError):
        kind, message = 'network', 'Kết nối tới dịch vụ tài khoản bị gián đoạn.'
    else:
        kind, retryable = 'response', False
        message = 'Phản hồi từ dịch vụ tài khoản chưa hợp lệ.'
    result = AccountError(message + ' Phiên đã lưu và Data trên máy được giữ.')
    result.connection = {'kind': kind, 'retryable': retryable}
    if status is not None:
        result.status = status
        result.connection['httpStatus'] = status
    elif isinstance(code, int):
        result.connection['osCode'] = code
    return result


def public_error(error):
    # No exception repr, request URL, headers, response body or credentials.
    return dict(getattr(error, 'connection', {'kind': 'response', 'retryable': False}))


def open_response(request, timeout):
    try:
        # HTTPS certificate verification stays enabled; credentials never redirect.
        return urllib.request.build_opener(NoRedirect()).open(request, timeout=timeout)
    except (urllib.error.URLError, TimeoutError, OSError, http.client.HTTPException) as error:
        raise failure(error) from None


def retry_read(action, retry=True):
    attempts = 2 if retry else 1
    for attempt in range(attempts):
        try:
            return action()
        except (AccountError, urllib.error.URLError, TimeoutError, OSError, http.client.HTTPException) as error:
            mapped = failure(error)
            if attempt + 1 == attempts or not public_error(mapped).get('retryable'):
                raise mapped from None
            time.sleep(0.25)


def json_reply(open_response_callback, maximum=8 * 1024**2, retry=True):
    def read():
        with open_response_callback() as response:
            raw = response.read(maximum + 1)
        if len(raw) > maximum:
            raise AccountError('Phản hồi tài khoản vượt giới hạn; Data trên máy được giữ.')
        try:
            value = json.loads(raw)
        except (ValueError, UnicodeError):
            raise AccountError('Phản hồi tài khoản chưa hợp lệ; Data trên máy được giữ.') from None
        if not isinstance(value, dict):
            raise AccountError('Phản hồi tài khoản chưa hợp lệ; Data trên máy được giữ.')
        return value
    return retry_read(read, retry=retry)
