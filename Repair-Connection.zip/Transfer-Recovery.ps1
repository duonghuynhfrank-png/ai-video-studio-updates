﻿function Stop-LegacyTransfer([string]$Root,[string]$Current,[string]$Python) {
  # Called only after Python validates the pinned signature of a newer small
  # update. Match this installation's exact stage command, never AI/app jobs.
  $client=Join-Path $Current 'python\update_client.py'
  $stageArgument='"'+$client+'" stage --root "'+$Root+'"'
  $jobs=@(Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object {
    $_.ExecutablePath -and $_.ExecutablePath.Equals($Python,[StringComparison]::OrdinalIgnoreCase) -and
    $_.CommandLine -and $_.CommandLine.Contains($stageArgument)
  })
  foreach($job in $jobs) {
    $parent=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$job.ParentProcessId) -ErrorAction SilentlyContinue
    if($parent -and $parent.Name -eq 'powershell.exe' -and $parent.CommandLine -and
       $parent.CommandLine.Contains('-File "'+$Root+'\Background-Update.ps1"') -and
       $parent.CommandLine.Contains('-InstallRoot "'+$Root+'"')) {
      Stop-Process -Id ([int]$parent.ProcessId) -ErrorAction Stop
    }
    $still=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$job.ProcessId) -ErrorAction SilentlyContinue
    if($still -and $still.CreationDate -eq $job.CreationDate -and $still.CommandLine -eq $job.CommandLine) {
      $handle=Get-Process -Id ([int]$job.ProcessId) -ErrorAction Stop
      Stop-Process -InputObject $handle -ErrorAction Stop
      [void]$handle.WaitForExit(10000)
    }
  }
  if($jobs.Count) { Write-Output 'Đã dừng đúng lượt cập nhật cũ để nhận gói thay đổi; app và Data được giữ.' }
}
