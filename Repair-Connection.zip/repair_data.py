"""Recover the installed app's own account Data; no credentials are copied."""
import argparse,json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import studio_account_client as accounts
from studio_data_sync import StudioCloud,local_inventory
from data_sync_core import DataSync,apply_pending,lock

def own_app_open(install):
    # Scope by the verified installation, rather than closing any process.
    root=str(install).replace("'","''")
    code="[bool](Get-Process ai_video_studio -ErrorAction SilentlyContinue | Where-Object {$_.Path -and $_.Path.StartsWith('"+root+"\\',[StringComparison]::OrdinalIgnoreCase)})"
    value=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',code],capture_output=True,text=True,timeout=20,check=True)
    return value.stdout.strip()=='True'

def data_root(local=None,roaming=None):
    local=Path(local or os.environ['LOCALAPPDATA'])
    roaming=Path(roaming or os.environ['APPDATA'])
    config=local/'AI Video Studio/storage.json'
    if config.is_file():
        value=json.loads(config.read_text('utf-8-sig')).get('supportDirectory')
        if not isinstance(value,str) or not Path(value).is_absolute():
            raise ValueError('Cấu hình kho Data không hợp lệ; giữ kho hiện có.')
        support=Path(value)
        if not support.is_dir():raise ValueError('Ổ chứa Data chưa sẵn sàng; không tạo kho trống thay thế.')
        return support/'ai_video_studio'
    # Same fallback as path_provider_windows + StudioStorage.
    return roaming/'vn.aivideostudio/ai_video_studio/ai_video_studio'

def recover(install,root,authorize=accounts.authorized,cloud_type=StudioCloud,sync_type=DataSync,
            apply=apply_pending,app_open=own_app_open):
    if app_open(install):
        return {'phase':'waiting-for-app-close','message':'Lưu công việc và đóng AI Video Studio trước khi áp dụng Data.','originalsPreserved':True}
    saved=authorize(root/'accounts')
    subject=accounts.subject(saved)
    print('Đang nhận và xác minh Data của phiên đăng nhập đã lưu…',flush=True)
    with lock(root):
        result=sync_type(root,cloud_type(saved),subject).run(stage_only=True)
        # Re-check the original app/session immediately before applying.
        if app_open(install):
            return {**result,'phase':'waiting-for-app-close','originalsPreserved':True}
        with accounts.session_lock(root/'accounts'):
            current=accounts.stored(root/'accounts')
            if not current or accounts.subject(current)!=subject:
                raise ValueError('Phiên đăng nhập đã đổi; Data đã nhận vẫn được giữ riêng, chưa áp dụng.')
            result=apply(root,subject)
    safe={k:result.get(k) for k in ['phase','uploaded','downloaded','pendingCount','conflictCount','deferredCount','uploadDeferredCount','message'] if k in result}
    return {**safe,**local_inventory(root,saved),'originalsPreserved':True,'newServicesOrFeesEnabled':False}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',required=True);parser.add_argument('--report',required=True)
    args=parser.parse_args();result={'originalsPreserved':True,'tokensLogged':False}
    try:
        root=data_root()
        if not root.is_dir() or not (root/'accounts/studio-session.dpapi').is_file():
            result.update(phase='signed-out',message='Kho đã chọn chưa có phiên đăng nhập. Mở app mới và đăng nhập cùng tài khoản; không đăng ký lại.')
        else:result.update(recover(Path(args.root),root))
    except Exception as error:
        result.update(phase='failed',errorType=type(error).__name__,message=str(error).split('?')[0][:300])
    Path(args.report).write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps(result,ensure_ascii=False),flush=True)
    if result['phase'] not in ['synced','signed-out']:sys.exit(1)

if __name__=='__main__':main()
