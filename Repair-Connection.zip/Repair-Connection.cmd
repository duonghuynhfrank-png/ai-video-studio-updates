@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-Connection.ps1"
echo.
echo Ket qua duoc luu trong CONNECTION.json va CONNECTION.log canh file nay.
pause
