"""Own Studio account Data transport; does not use Google or OpenAI."""
import argparse
import hashlib
import http.client
import os
import secrets
import json
from pathlib import Path
import re
import sys
import urllib.parse
import studio_account_client as accounts
import studio_http
from data_sync_core import DataSync, SyncError, apply_pending, digest, load, lock, target


class StudioCloud:
    def __init__(self, saved):
        self.saved = saved

    def request(self, path, data=None, method=None, headers=None, timeout=120):
        return accounts.request(self.saved['base'], path, self.saved['token'], data, method,
            headers={'X-Studio-Owner': self.saved['profile']['id'], **(headers or {})}, timeout=timeout)

    def files(self, kind):
        rows, after = [], 0
        while True:
            query = urllib.parse.urlencode({'kind': kind, 'after': after})
            value = studio_http.json_reply(
                lambda: self.request('/v1/data/files?' + query, timeout=12))
            if not isinstance(value.get('files'), list):
                raise SyncError('Danh mục Data chưa hợp lệ; giữ Data tại máy.')
            rows.extend(value['files'])
            if len(rows) > 100000:
                raise SyncError('Lịch sử Data vượt giới hạn bản này.')
            next_page = value.get('nextPage')
            if next_page is None:
                return rows
            if not isinstance(next_page, int) or next_page <= after:
                raise SyncError('Trang Data chưa hợp lệ.')
            after = next_page

    def download(self, file_id, destination, maximum):
        if not re.fullmatch(r'[a-f0-9]{32}', file_id):
            raise SyncError('Mã file Data chưa hợp lệ.')
        destination = Path(destination)
        temporary = destination.with_name(destination.name + '.receiving-' + secrets.token_hex(8))
        def receive():
            with self.request('/v1/data/files/' + file_id) as response, temporary.open('wb') as output:
                count = 0
                while True:
                    block = response.read(1024**2)
                    if not block:
                        break
                    count += len(block)
                    if count > maximum:
                        raise SyncError('File Data vượt kích thước khai báo.')
                    output.write(block)
                length = response.headers.get('Content-Length')
                if length is not None and (not length.isdigit() or count != int(length)):
                    raise http.client.IncompleteRead(b'')
        try:
            studio_http.retry_read(receive)
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)

    def upload(self, source, kind, key):
        size = source.stat().st_size
        with self.request('/v1/data/files', {'kind': kind, 'key': key, 'bytes': size}) as response:
            value = json.load(response)
        file_id = value['id']
        if not re.fullmatch(r'[a-f0-9]{32}', file_id):
            raise SyncError('Mã file Data chưa hợp lệ.')
        if not value.get('complete'):
            chunk_bytes = value.get('chunkBytes')
            if chunk_bytes is not None:
                if type(chunk_bytes) is not int or not 1024**2 <= chunk_bytes <= 8 * 1024**2:
                    raise SyncError('Kích thước phần truyền Data chưa hợp lệ.')
                with source.open('rb') as stream:
                    for part, start in enumerate(range(0, size, chunk_bytes)):
                        data = stream.read(min(chunk_bytes, size - start))
                        if len(data) != min(chunk_bytes, size - start):
                            raise SyncError('File nguồn thay đổi khi truyền; bản gốc được giữ.')
                        with self.request('/v1/data/files/' + file_id + '?part=' + str(part), data, 'PUT',
                            {'Content-Type': 'application/octet-stream', 'Content-Length': str(len(data)),
                             'X-Part-Sha256': hashlib.sha256(data).hexdigest()}) as response:
                            if json.load(response).get('stored') is not True:
                                raise SyncError('Máy chủ chưa nhận đủ phần Data.')
                with self.request('/v1/data/files/' + file_id + '/complete', {}) as response:
                    if json.load(response).get('complete') is not True:
                        raise SyncError('Máy chủ chưa xác minh đủ file Data.')
            else:
                with source.open('rb') as stream, self.request('/v1/data/files/' + file_id, stream, 'PUT',
                      {'Content-Type': 'application/octet-stream', 'Content-Length': str(size)}) as response:
                    if json.load(response).get('complete') is not True:
                        raise SyncError('Máy chủ chưa nhận đủ file Data.')
        return file_id


def local_inventory(root, saved):
    # Counts describe this device, not a claim about another PC. Read only
    # bounded metadata and file presence; never decode images or run AI here.
    if not saved:
        return {}
    accounts.check_binding(root/'accounts', saved)
    owner = digest(accounts.subject(saved).encode())
    counts = {'localProjects': 0, 'localPhotos': 0, 'missingPhotos': 0}
    def metadata(relative):
        file = target(root, relative)
        if not file.is_file(): return {}
        if file.stat().st_size > 4*1024**2: raise SyncError('Danh mục Data quá lớn.')
        return load(file, {})
    for project in metadata('project_catalog.json').get('projects', []):
        key = project.get('id', '')
        if project.get('archived') or not re.fullmatch(r'[A-Za-z0-9_-]+', key): continue
        counts['localProjects'] += 1
        base = 'projects/' + key + '/production/'
        library = metadata(base + 'provided_photos/' + owner + '/library.json')
        if not library: continue
        if library.get('ownerKey') != owner or library.get('projectId') != key:
            raise SyncError('Kho ảnh không thuộc tài khoản/dự án này.')
        for item in library.get('items', []):
            if item.get('removed'): continue
            file = target(root, base + item['path'])
            counts['localPhotos' if file.is_file() else 'missingPhotos'] += 1
    return counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['local-status', 'status', 'sync', 'apply'])
    parser.add_argument('--store', required=True)
    parser.add_argument('--data-root', required=True)
    args = parser.parse_args()
    root, store = Path(args.data_root), Path(args.store)
    # Already verified incoming files can be applied offline. Login/logout and
    # the local account binding remain authoritative; never adopt another user.
    if args.operation == 'apply':
        with accounts.session_lock(store):
            saved = accounts.stored(store)
            if saved:
                accounts.check_binding(store, saved)
                with lock(root):
                    result = apply_pending(root, accounts.subject(saved))
            else:
                result = {'phase': 'signed-out'}
        print(json.dumps({**result, **local_inventory(root, accounts.stored(store))}, ensure_ascii=False)); return
    if args.operation == 'local-status':
        saved = accounts.stored(store)
        result = {'phase': 'signed-out'}
        if saved:
            accounts.check_binding(store, saved)
            old = load(root / '.sync' / 'status.json', {})
            subject = accounts.subject(saved)
            if old.get('account') == digest(subject.encode()):
                result = old
            else:
                result = {'phase': 'ready'}
        print(json.dumps({**result, **local_inventory(root, accounts.stored(store))}, ensure_ascii=False)); return
    account = accounts.status(store)
    saved = accounts.stored(store)
    result = {'phase': 'signed-out' if not saved else 'ready'}
    if saved:
        subject = accounts.subject(saved)
        old = load(root / '.sync' / 'status.json', {})
        if old.get('account') == digest(subject.encode()):
            result.update(old)
        if not account.get('connected'):
            result.update(phase='offline', message=account.get('message', 'Chưa kết nối được dịch vụ tài khoản.'), connectionError=account.get('connectionError'))
            print(json.dumps({**result, **local_inventory(root, accounts.stored(store))}, ensure_ascii=False)); return
        if args.operation == 'sync':
            saved = accounts.authorized(store)
            with lock(root):
                result = DataSync(root, StudioCloud(saved), subject).run(stage_only=True)
    print(json.dumps({**result, **local_inventory(root, accounts.stored(store))}, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (SyncError, accounts.AccountError) as exc:
        print(str(exc), file=sys.stderr); sys.exit(1)
    except Exception:
        print('Chưa đồng bộ được Data; dữ liệu trên máy được giữ.', file=sys.stderr); sys.exit(1)
