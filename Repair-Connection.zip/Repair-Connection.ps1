﻿param([string]$InstallRoot='', [switch]$DiagnoseOnly)
$ErrorActionPreference='Stop'
$log=Join-Path $PSScriptRoot 'CONNECTION.log'
$report=Join-Path $PSScriptRoot 'CONNECTION.json'
Start-Transcript -LiteralPath $log -Force | Out-Null
function Find-Install {
  $candidates=New-Object 'Collections.Generic.List[string]'
  if($InstallRoot){$candidates.Add([IO.Path]::GetFullPath($InstallRoot))}
  else{
    foreach($app in Get-Process ai_video_studio -ErrorAction SilentlyContinue){
      try{$path=$app.Path}catch{continue}
      if($path -and (Split-Path (Split-Path (Split-Path $path -Parent) -Parent) -Leaf) -eq 'versions'){
        $candidates.Add((Split-Path (Split-Path (Split-Path $path -Parent) -Parent) -Parent))
      }
    }
    $registered=(Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIVideoStudioLocal' -ErrorAction SilentlyContinue).InstallLocation
    if($registered){$candidates.Add($registered)}
    $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\AI Video Studio'))
    $candidates.Add('D:\AI Video Studio\App')
    $cursor=$PSScriptRoot
    for($i=0;$i -lt 4 -and $cursor;$i++){
      $candidates.Add($cursor);$candidates.Add((Join-Path $cursor 'App'));$cursor=Split-Path $cursor -Parent
    }
  }
  foreach($candidate in $candidates){
    if((Test-Path -LiteralPath (Join-Path $candidate 'installation.json')) -and (Test-Path -LiteralPath (Join-Path $candidate 'update-trust.json'))){return [IO.Path]::GetFullPath($candidate).TrimEnd('\')}
  }
  throw 'Chưa tìm thấy app đã cài. Giải nén gói này vào thư mục app hoặc chạy với -InstallRoot trỏ tới thư mục có installation.json.'
}
try{
  $root=Find-Install
  Write-Output ('Đã tìm thấy app tại: '+$root)
  $info=Get-Content -LiteralPath (Join-Path $root 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  if([IO.Path]::IsPathRooted($info.current)){
    if((Split-Path (Split-Path $info.current -Parent) -Leaf) -ne 'versions'){throw 'Đường dẫn phiên bản chưa hợp lệ.'}
    $current=Join-Path (Join-Path $root 'versions') (Split-Path $info.current -Leaf)
  }else{$current=[IO.Path]::GetFullPath((Join-Path $root $info.current))}
  if(-not $current.StartsWith($root+'\versions\',[StringComparison]::OrdinalIgnoreCase)){throw 'Đường dẫn phiên bản chưa hợp lệ.'}
  $python=Join-Path $current 'python\python.exe'
  if(-not(Test-Path -LiteralPath $python)){throw 'Bản app thiếu Python đi kèm; giữ nguyên Data.'}
  $entry=Join-Path $PSScriptRoot 'connection_doctor.py'
  $arguments=@($entry,'--root',$root,'--report',$report)
  if(-not $DiagnoseOnly){$arguments+='--stage'}
  & $python @arguments
  if($LASTEXITCODE -ne 0){throw 'Chưa hoàn tất kết nối/tải bản mới. Nguyên nhân được ghi trong CONNECTION.json.'}
  $result=Get-Content -LiteralPath $report -Raw -Encoding UTF8 | ConvertFrom-Json
  if(-not $DiagnoseOnly -and $result.updates.signatureVerified -and (Test-Path -LiteralPath (Join-Path $root 'AI Video Studio.exe'))){
    # Normal launches use the native EXE; repair old Run/cmd shortcuts only
    # when they belong to this installation. Never repoint another app copy.
    $shell=New-Object -ComObject WScript.Shell
    $desktop=[Environment]::GetFolderPath('Desktop')
    $menu=Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\AI Video Studio'
    [IO.Directory]::CreateDirectory($menu) | Out-Null
    foreach($folder in @($desktop,$menu)){
      $link=Join-Path $folder 'AI Video Studio.lnk'
      $shortcut=$shell.CreateShortcut($link)
      if((Test-Path -LiteralPath $link) -and $shortcut.TargetPath){
        $oldTarget=[IO.Path]::GetFullPath($shortcut.TargetPath)
        if(-not $oldTarget.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){continue}
      }
      $shortcut.TargetPath=Join-Path $root 'AI Video Studio.exe'
      $shortcut.Arguments='';$shortcut.WorkingDirectory=$root
      $shortcut.IconLocation=(Join-Path $current 'ai_video_studio.exe')+',0'
      $shortcut.Save()
    }
    Write-Output 'Lần sau mở bằng biểu tượng AI Video Studio trên Desktop; bộ khởi động chạy ẩn.'
  }
  if($result.staging.pendingVersion){
    $app=Get-Process ai_video_studio -ErrorAction SilentlyContinue | Where-Object {$_.Path -and $_.Path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)}
    if(-not $app -and (Test-Path -LiteralPath (Join-Path $root 'AI Video Studio.exe'))){
      Start-Process -FilePath (Join-Path $root 'AI Video Studio.exe') -WindowStyle Normal
      Write-Output 'Đã mở bộ khởi động để áp dụng bản đã xác minh. Kiểm tra phiên bản khi app mở lại.'
    }
  }
  Write-Output 'Kiểm tra hoàn tất. Gói không yêu cầu mật khẩu, đăng ký lại hoặc cấu hình Google/GitHub.'
  Write-Output 'Nếu app cũ vẫn mở, lưu công việc, đóng app rồi mở lại bằng biểu tượng AI Video Studio để nhận bản đã chuẩn bị.'
}catch{
  Write-Output ('Lỗi: '+$_.Exception.Message)
  if(-not(Test-Path -LiteralPath $report)){@{failed=$true;message=$_.Exception.Message;userDataModified=$false} | ConvertTo-Json | Set-Content -LiteralPath $report -Encoding UTF8}
  exit 1
}finally{Stop-Transcript | Out-Null}
