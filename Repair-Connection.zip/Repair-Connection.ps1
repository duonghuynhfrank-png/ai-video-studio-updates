﻿param([string]$InstallRoot='', [switch]$DiagnoseOnly)
$ErrorActionPreference='Stop'
$nativeModules=Join-Path $PSHOME 'Modules'
$env:PSModulePath=$nativeModules+';'+$env:PSModulePath
Import-Module (Join-Path $nativeModules 'Microsoft.PowerShell.Utility\Microsoft.PowerShell.Utility.psd1') -ErrorAction Stop
$log=Join-Path $PSScriptRoot 'CONNECTION.log'
$report=Join-Path $PSScriptRoot 'CONNECTION.json'
Start-Transcript -LiteralPath $log -Force | Out-Null
function Find-Install {
  $candidates=New-Object 'Collections.Generic.List[string]'
  if($InstallRoot){$candidates.Add([IO.Path]::GetFullPath($InstallRoot))}
  else{
    foreach($app in Get-Process ai_video_studio -ErrorAction SilentlyContinue){
      try{$path=$app.Path}catch{continue}
      if($path -and (Split-Path (Split-Path (Split-Path $path -Parent) -Parent) -Leaf) -eq 'versions'){
        $candidates.Add((Split-Path (Split-Path (Split-Path $path -Parent) -Parent) -Parent))
      }
    }
    $registered=(Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIVideoStudioLocal' -ErrorAction SilentlyContinue).InstallLocation
    if($registered){$candidates.Add($registered)}
    $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\AI Video Studio'))
    $candidates.Add('D:\AI Video Studio\App')
    $cursor=$PSScriptRoot
    for($i=0;$i -lt 4 -and $cursor;$i++){
      $candidates.Add($cursor);$candidates.Add((Join-Path $cursor 'App'));$cursor=Split-Path $cursor -Parent
    }
  }
  foreach($candidate in $candidates){
    if((Test-Path -LiteralPath (Join-Path $candidate 'installation.json')) -and (Test-Path -LiteralPath (Join-Path $candidate 'update-trust.json'))){return [IO.Path]::GetFullPath($candidate).TrimEnd('\')}
  }
  throw 'Chưa tìm thấy app đã cài. Giải nén gói này vào thư mục app hoặc chạy với -InstallRoot trỏ tới thư mục có installation.json.'
}
try{
  $root=Find-Install
  Write-Output ('Đã tìm thấy app tại: '+$root)
  $info=Get-Content -LiteralPath (Join-Path $root 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  if([IO.Path]::IsPathRooted($info.current)){
    if((Split-Path (Split-Path $info.current -Parent) -Leaf) -ne 'versions'){throw 'Đường dẫn phiên bản chưa hợp lệ.'}
    $current=Join-Path (Join-Path $root 'versions') (Split-Path $info.current -Leaf)
  }else{$current=[IO.Path]::GetFullPath((Join-Path $root $info.current))}
  if(-not $current.StartsWith($root+'\versions\',[StringComparison]::OrdinalIgnoreCase)){throw 'Đường dẫn phiên bản chưa hợp lệ.'}
  $python=Join-Path $current 'python\python.exe'
  if(-not(Test-Path -LiteralPath $python)){throw 'Bản app thiếu Python đi kèm; giữ nguyên Data.'}
  $entry=Join-Path $PSScriptRoot 'connection_doctor.py'
  $arguments=@($entry,'--root',$root,'--report',$report)
  if(-not $DiagnoseOnly){
    $approved=& $python @arguments --preflight
    if($LASTEXITCODE -ne 0){throw 'Chưa xác minh được bản phát hành trước khi tiếp quản lượt cập nhật cũ.'}
    $preflight=($approved -join "`n") | ConvertFrom-Json
    if($preflight.canReplaceTransfer){
      . (Join-Path $PSScriptRoot 'Transfer-Recovery.ps1')
      Stop-LegacyTransfer $root $current $python
    }
    $arguments+='--stage'
  }
  & $python @arguments
  if($LASTEXITCODE -ne 0){throw 'Chưa hoàn tất kết nối/tải bản mới. Nguyên nhân được ghi trong CONNECTION.json.'}
  $result=Get-Content -LiteralPath $report -Raw -Encoding UTF8 | ConvertFrom-Json
  if($result.staging.pendingVersion){
    $pending=Get-Content -LiteralPath (Join-Path $root 'updates\pending.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $candidate=[IO.Path]::GetFullPath((Join-Path $root $pending.candidate))
    if(-not $candidate.StartsWith($root+'\versions\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid pending candidate.'}
    $manifestPath=Join-Path $candidate 'package-manifest.json'
    if((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pending.manifestSha256){throw 'Pending manifest changed.'}
    $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $common=Join-Path $candidate 'maintenance\Update.Common.ps1'
    $record=@($manifest.files | Where-Object { $_.path -replace '\\','/' -eq 'maintenance/Update.Common.ps1' })
    if($record.Count -ne 1 -or (Get-FileHash -LiteralPath $common -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record[0].sha256){throw 'Candidate updater checksum mismatch.'}
    . $common
    $activation=New-Object Threading.Mutex($false,(Activation-MutexName $root));$ownsActivation=$false
    try{
      try{$ownsActivation=$activation.WaitOne(0)}catch [Threading.AbandonedMutexException]{$ownsActivation=$true}
      if(-not $ownsActivation){
        $installedCommon=Join-Path $root 'Update.Common.ps1'
        $oldVerifier=(Test-Path -LiteralPath $installedCommon) -and -not ([IO.File]::ReadAllText($installedCommon).Contains('class StudioNativeUpdateVerifier'))
        if($oldVerifier){
          $stateFile=Join-Path $root 'updates\background-status.json'
          if(Test-Path -LiteralPath $stateFile){
            $state=Get-Content -LiteralPath $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if($state.phase -eq 'checking' -and $state.pid){
              $oldWorker=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$state.pid)
              $fileArgument='-File "'+$root+'\Background-Update.ps1"'
              $rootArgument='-InstallRoot "'+$root+'"'
              if($oldWorker.Name -eq 'powershell.exe' -and $oldWorker.CommandLine.Contains($fileArgument) -and $oldWorker.CommandLine.Contains($rootArgument)){
                Stop-Process -Id ([int]$state.pid) -ErrorAction Stop
                Write-Output 'Đã dừng đúng lượt kiểm tra nền cũ để dùng bộ xác minh mới.'
                try{$ownsActivation=$activation.WaitOne(10000)}catch [Threading.AbandonedMutexException]{$ownsActivation=$true}
              }
            }
          }
        }
      }
      if($ownsActivation){
        $safe=$false;try{Assert-Idle $root;$safe=$true}catch{}
        if($safe){[void](Activate-Pending $root);Write-Output 'Đã áp dụng bản cập nhật bằng bộ xác minh mới.'}
      }
    }finally{if($ownsActivation){$activation.ReleaseMutex()};$activation.Dispose()}
    $app=Get-Process ai_video_studio -ErrorAction SilentlyContinue | Where-Object {$_.Path -and $_.Path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)}
    if(-not $app -and (Test-Path -LiteralPath (Join-Path $root 'AI Video Studio.exe'))){
      Start-Process -FilePath (Join-Path $root 'AI Video Studio.exe') -WindowStyle Normal
      Write-Output 'Đã mở bộ khởi động để áp dụng bản đã xác minh. Kiểm tra phiên bản khi app mở lại.'
    }
  }
  Write-Output 'Kiểm tra hoàn tất. Gói không yêu cầu mật khẩu, đăng ký lại hoặc cấu hình Google/GitHub.'
}catch{
  Write-Output ('Lỗi: '+$_.Exception.Message)
  if(-not(Test-Path -LiteralPath $report)){@{failed=$true;message=$_.Exception.Message;userDataModified=$false} | ConvertTo-Json | Set-Content -LiteralPath $report -Encoding UTF8}
  exit 1
}finally{Stop-Transcript | Out-Null}
