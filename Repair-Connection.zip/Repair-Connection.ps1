﻿param([string]$InstallRoot='', [switch]$DiagnoseOnly)
$ErrorActionPreference='Stop'
$log=Join-Path $PSScriptRoot 'CONNECTION.log'
$report=Join-Path $PSScriptRoot 'CONNECTION.json'
Start-Transcript -LiteralPath $log -Force | Out-Null
function Shortcut-BelongsToInstall($Shortcut,[string]$Root) {
  if(-not $Shortcut.TargetPath){return $false}
  $target=[IO.Path]::GetFullPath($Shortcut.TargetPath)
  if($target.StartsWith($Root+'\',[StringComparison]::OrdinalIgnoreCase)){return $true}
  $system=[Environment]::GetFolderPath('System')
  $knownShells=@((Join-Path $system 'WindowsPowerShell\v1.0\powershell.exe'),(Join-Path $system 'cmd.exe'))
  if(-not ($knownShells -contains $target)){return $false}
  foreach($name in @('Launch.ps1','Run.ps1','Run.cmd')){
    $script=Join-Path $Root $name
    if(([string]$Shortcut.Arguments).IndexOf('"'+$script+'"',[StringComparison]::OrdinalIgnoreCase) -ge 0){return $true}
  }
  return $false
}
function Find-Install {
  $candidates=New-Object 'Collections.Generic.List[string]'
  if($InstallRoot){$candidates.Add([IO.Path]::GetFullPath($InstallRoot))}
  else{
    foreach($app in Get-Process ai_video_studio -ErrorAction SilentlyContinue){
      try{$path=$app.Path}catch{continue}
      if($path -and (Split-Path (Split-Path (Split-Path $path -Parent) -Parent) -Leaf) -eq 'versions'){
        $candidates.Add((Split-Path (Split-Path (Split-Path $path -Parent) -Parent) -Parent))
      }
    }
    $registered=(Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIVideoStudioLocal' -ErrorAction SilentlyContinue).InstallLocation
    if($registered){$candidates.Add($registered)}
    $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\AI Video Studio'))
    $candidates.Add('D:\AI Video Studio\App')
    $cursor=$PSScriptRoot
    for($i=0;$i -lt 4 -and $cursor;$i++){
      $candidates.Add($cursor);$candidates.Add((Join-Path $cursor 'App'));$cursor=Split-Path $cursor -Parent
    }
  }
  foreach($candidate in $candidates){
    if((Test-Path -LiteralPath (Join-Path $candidate 'installation.json')) -and (Test-Path -LiteralPath (Join-Path $candidate 'update-trust.json'))){return [IO.Path]::GetFullPath($candidate).TrimEnd('\')}
  }
  throw 'Chưa tìm thấy app đã cài. Giải nén gói này vào thư mục app hoặc chạy với -InstallRoot trỏ tới thư mục có installation.json.'
}
try{
  $root=Find-Install
  Write-Output ('Đã tìm thấy app tại: '+$root)
  $info=Get-Content -LiteralPath (Join-Path $root 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  if([IO.Path]::IsPathRooted($info.current)){
    if((Split-Path (Split-Path $info.current -Parent) -Leaf) -ne 'versions'){throw 'Đường dẫn phiên bản chưa hợp lệ.'}
    $current=Join-Path (Join-Path $root 'versions') (Split-Path $info.current -Leaf)
  }else{$current=[IO.Path]::GetFullPath((Join-Path $root $info.current))}
  if(-not $current.StartsWith($root+'\versions\',[StringComparison]::OrdinalIgnoreCase)){throw 'Đường dẫn phiên bản chưa hợp lệ.'}
  $python=Join-Path $current 'python\python.exe'
  if(-not(Test-Path -LiteralPath $python)){throw 'Bản app thiếu Python đi kèm; giữ nguyên Data.'}
  $entry=Join-Path $PSScriptRoot 'connection_doctor.py'
  $arguments=@($entry,'--root',$root,'--report',$report)
  if(-not $DiagnoseOnly){$arguments+='--stage'}
  & $python @arguments
  if($LASTEXITCODE -ne 0){Write-Output 'Phần cập nhật chưa hoàn tất; vẫn kiểm tra nhận Data riêng. Nguyên nhân ở CONNECTION.json.'}
  $result=Get-Content -LiteralPath $report -Raw -Encoding UTF8 | ConvertFrom-Json
  if(-not $DiagnoseOnly -and $result.updates.signatureVerified -and (Test-Path -LiteralPath (Join-Path $root 'AI Video Studio.exe'))){
    # Normal launches use the native EXE; repair old Run/cmd shortcuts only
    # when they belong to this installation. Never repoint another app copy.
    $shell=New-Object -ComObject WScript.Shell
    $desktop=[Environment]::GetFolderPath('Desktop')
    $menu=Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\AI Video Studio'
    [IO.Directory]::CreateDirectory($menu) | Out-Null
    foreach($folder in @($desktop,$menu)){
      $link=Join-Path $folder 'AI Video Studio.lnk'
      $shortcut=$shell.CreateShortcut($link)
      if((Test-Path -LiteralPath $link) -and $shortcut.TargetPath){
        if(-not (Shortcut-BelongsToInstall $shortcut $root)){continue}
      }
      $shortcut.TargetPath=Join-Path $root 'AI Video Studio.exe'
      $shortcut.Arguments='';$shortcut.WorkingDirectory=$root
      $shortcut.IconLocation=(Join-Path $current 'ai_video_studio.exe')+',0'
      $shortcut.Save()
    }
    Write-Output 'Lần sau mở bằng biểu tượng AI Video Studio trên Desktop; bộ khởi động chạy ẩn.'
  }
  $apps=@(Get-Process ai_video_studio -ErrorAction SilentlyContinue | Where-Object {$_.Path -and $_.Path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)})
  if($apps){
    Write-Output 'Đã kiểm tra/tải cập nhật. Hãy lưu và đóng AI Video Studio rồi chạy lại gói này để áp dụng bản mới và nhận Data. Không tự đóng công việc của bạn.'
  }else{
    $pendingPath=Join-Path $root 'updates\pending.json'
    if(Test-Path -LiteralPath $pendingPath){
      $pending=Get-Content -LiteralPath $pendingPath -Raw -Encoding UTF8 | ConvertFrom-Json
      $candidate=[IO.Path]::GetFullPath((Join-Path $root $pending.candidate))
      if(-not $candidate.StartsWith($root+'\versions\',[StringComparison]::OrdinalIgnoreCase)){throw 'Bản chờ nằm ngoài thư mục phiên bản.'}
      $helper=Join-Path $candidate 'maintenance\Update.Common.ps1'
      if(-not(Test-Path -LiteralPath $helper)){throw 'Bản đã xác minh thiếu bộ áp dụng.'}
      . $helper
      $activation=New-Object Threading.Mutex($false,(Activation-MutexName $root));$owned=$false
      try{
        $owned=$activation.WaitOne(0)
        if(-not $owned){throw 'Bộ cập nhật đang áp dụng; chạy lại khi lượt đó hoàn tất.'}
        Assert-Idle $root
        if(-not(Activate-Pending $root)){throw 'Chưa áp dụng được bản đã xác minh; Data được giữ.'}
      }finally{if($owned){$activation.ReleaseMutex()};$activation.Dispose()}
      Write-Output 'Đã áp dụng bản mới sau khi xác minh, không thay kho Data hoặc model.'
    }
    $info=Get-Content -LiteralPath (Join-Path $root 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $current=[IO.Path]::GetFullPath((Join-Path $root $info.current))
    if(-not $current.StartsWith($root+'\versions\',[StringComparison]::OrdinalIgnoreCase)){throw 'Đường dẫn bản cài không hợp lệ.'}
    $python=Join-Path $current 'python\python.exe'
    $register=Join-Path $root 'Register-BackgroundUpdates.ps1'
    if(Test-Path -LiteralPath $register){& $register -InstallRoot $root -StartNow}
    $dataReport=Join-Path $PSScriptRoot 'DATA.json'
    & $python (Join-Path $PSScriptRoot 'repair_data.py') --root $root --report $dataReport
    if($LASTEXITCODE -ne 0){Write-Output 'Data chưa hoàn tất; chi tiết ở DATA.json. File gốc vẫn được giữ, không tự mua thêm dung lượng.'}
    elseif(Test-Path -LiteralPath $dataReport){
      $data=Get-Content -LiteralPath $dataReport -Raw -Encoding UTF8 | ConvertFrom-Json
      if($data.phase -eq 'synced'){Write-Output ('Đã xác minh Data trên PC này: '+$data.localProjects+' dự án, '+$data.localPhotos+' ảnh, thiếu '+$data.missingPhotos+' ảnh.')}
      else{Write-Output $data.message}
    }
    if(Test-Path -LiteralPath (Join-Path $root 'AI Video Studio.exe')){
      Start-Process -FilePath (Join-Path $root 'AI Video Studio.exe') -WindowStyle Normal
      Write-Output ('Đã mở bản '+$info.version+'. Lần sau mở bằng biểu tượng AI Video Studio, cập nhật chạy ẩn.')
    }
  }
  Write-Output 'Kết quả cập nhật: CONNECTION.json. Kết quả nhận Data: DATA.json. Không đăng ký lại hoặc cấu hình Google/GitHub.'
  Write-Output 'Nếu app cũ vẫn mở, lưu công việc, đóng app rồi mở lại bằng biểu tượng AI Video Studio để nhận bản đã chuẩn bị.'
}catch{
  Write-Output ('Lỗi: '+$_.Exception.Message)
  if(-not(Test-Path -LiteralPath $report)){@{failed=$true;message=$_.Exception.Message;userDataModified=$false} | ConvertTo-Json | Set-Content -LiteralPath $report -Encoding UTF8}
  exit 1
}finally{Stop-Transcript | Out-Null}
