"""Bounded, resumable downloads and Windows-safe release paths."""
import hashlib
import json
import os
import time
import uuid
from pathlib import Path
import urllib.parse
import urllib.request


def read_json(path):
    return json.loads(Path(path).read_text('utf-8-sig'))


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp-' + str(os.getpid()) + '-' + uuid.uuid4().hex)
    try:
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), 'utf-8')
        for attempt in range(7):
            try:
                os.replace(temporary, path)
                break
            except PermissionError:
                if attempt == 6:
                    raise
                # A Windows reader/antivirus can briefly hold a status file.
                # Keep the original intact, then retry the same atomic commit.
                time.sleep(min(.04 * 2 ** attempt, .3))
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass  # Cleanup must never replace the real write failure.


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def child(root, relative):
    root = Path(root).resolve()
    raw = str(relative).replace('\\', '/')
    parts = raw.split('/')
    reserved = {'CON', 'PRN', 'AUX', 'NUL', *('COM' + str(i) for i in range(1, 10)), *('LPT' + str(i) for i in range(1, 10))}
    if not raw or raw.startswith('/') or any(not p or p in ('.', '..') or ':' in p or p.endswith((' ', '.')) or p.split('.')[0].upper() in reserved for p in parts):
        raise ValueError('Đường dẫn trong bản phát hành không hợp lệ.')
    result = root.joinpath(*parts)
    if not result.resolve().is_relative_to(root):
        raise ValueError('Đường dẫn thoát khỏi thư mục ứng dụng.')
    cursor = result
    while cursor != root:
        if cursor.is_symlink() or cursor.is_junction():
            raise ValueError('Không ghi bản cập nhật qua đường dẫn liên kết.')
        cursor = cursor.parent
    return result


def validate_url(url, allow_loopback=False):
    parsed = urllib.parse.urlsplit(url)
    if parsed.username or parsed.password or not parsed.hostname or parsed.fragment:
        raise ValueError('Địa chỉ tải không hợp lệ.')
    if parsed.scheme != 'https' and not (allow_loopback and parsed.scheme == 'http' and parsed.hostname in ('127.0.0.1', 'localhost', '::1')):
        raise ValueError('Bản phát hành cần địa chỉ HTTPS.')
    return url


class SecureRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, allow_loopback=False):
        self.allow_loopback = allow_loopback

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_url(newurl, self.allow_loopback)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def open_url(url, headers=None, allow_loopback=False, timeout=45):
    validate_url(url, allow_loopback)
    request = urllib.request.Request(url, headers={'User-Agent': 'AI-Video-Studio-Updater/1', **(headers or {})})
    return urllib.request.build_opener(SecureRedirect(allow_loopback)).open(request, timeout=timeout)


def download(url, target, size, expected_sha256, progress=None, allow_loopback=False):
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file() and target.stat().st_size == size and digest(target) == expected_sha256:
        return 'existing'
    partial = target.with_name(target.name + '.partial')
    if partial.exists() and partial.stat().st_size > size:
        partial.unlink()
    offset = partial.stat().st_size if partial.exists() else 0
    if offset == size:
        if digest(partial) == expected_sha256:
            os.replace(partial, target)
            return 'resumed'
        partial.unlink()
        offset = 0
    headers = {'Range': 'bytes=' + str(offset) + '-'} if offset else {}
    with open_url(url, headers, allow_loopback) as response:
        if offset and response.status != 206:
            offset = 0
        if offset and not response.headers.get('Content-Range', '').startswith('bytes ' + str(offset) + '-'):
            raise ValueError('Máy chủ trả sai vị trí tiếp tục tải.')
        mode = 'ab' if offset else 'wb'
        received = offset
        with partial.open(mode) as stream:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                received += len(chunk)
                if received > size:
                    raise ValueError('File tải lớn hơn kích thước đã công bố.')
                stream.write(chunk)
                if progress:
                    progress(received, size)
    if received != size or digest(partial) != expected_sha256:
        partial.unlink(missing_ok=True)
        raise ValueError('File tải thiếu hoặc sai checksum; bản đang dùng được giữ.')
    os.replace(partial, target)
    return 'downloaded'
