"""Provider independent immutable Data revisions and local CAS apply."""
import argparse
from contextlib import contextmanager
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid


APP = 'vn.aivideostudio.data.v1'
MAX_FILE = 4 * 1024**3
MAX_MANIFEST = 8 * 1024**2
CATALOGS = {'project_catalog.json', 'knowledge_catalog.json', 'knowledge/knowledge_catalog.json', 'knowledge/user_sources.json'}
TOP_DIRS = {'projects', 'knowledge', 'knowledge_inbox', 'voices'}
TOP_FILES = {'project_catalog.json', 'knowledge_catalog.json'}
EXCLUDED = {'.sync', 'accounts', 'chatgpt', 'models', 'cache', '__pycache__'}
TEMP_SUFFIXES = ('.tmp', '.bak', '.lock', '.part', '.bundle-installing', '.response.txt',
                 '.incoming', '.extracting.png', '.extracting.wav', 'transcribe_16k.wav')
BIN_SUFFIXES = {'.exe', '.dll', '.so', '.bat', '.cmd', '.ps1', '.py', '.pfx', '.pem', '.dpapi', '.key', '.gguf', '.safetensors', '.onnx', '.pt', '.pth', '.ckpt', '.tflite', '.env'}

class SyncError(Exception):
    pass

def encode(value):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def load(path, default):
    return json.loads(path.read_text('utf-8-sig')) if path.is_file() else default

def atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_bytes(encode(value)); os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)

def allowed(relative):
    if not isinstance(relative, str) or '\\' in relative or ':' in relative or '\x00' in relative:
        return False
    parts = relative.split('/')
    if any(p in ('', '.', '..') or p.lower() in EXCLUDED or p.rstrip(' .') != p for p in parts):
        return False
    if PurePosixPath(relative).is_absolute() or (parts[0] not in TOP_DIRS and relative not in TOP_FILES):
        return False
    return not relative.lower().endswith(TEMP_SUFFIXES) and Path(relative).suffix.lower() not in BIN_SUFFIXES

def target(root, relative):
    if not allowed(relative):
        raise SyncError('Đường dẫn Data đồng bộ không hợp lệ.')
    root = root.absolute()
    path = root.joinpath(*relative.split('/'))
    for part in [root, *list(path.parents)[:-1], path]:
        if part.exists() and (part.is_symlink() or getattr(part.lstat(), 'st_file_attributes', 0) & 0x400):
            raise SyncError('Không đồng bộ đường dẫn liên kết tới nơi khác.')
    if not path.resolve().is_relative_to(root.resolve()):
        raise SyncError('Data nằm ngoài kho ứng dụng.')
    return path

def normalized(relative, data):
    if relative in CATALOGS:
        value = json.loads(data)
        if not isinstance(value, dict):
            raise SyncError('Catalog Data không hợp lệ.')
        value.pop('activeProjectId', None)
        value.pop('selectedId', None)
        return encode(value)
    return data

def snapshot(root):
    result = {}
    for folder, directories, files in os.walk(root, followlinks=False):
        directories[:] = [d for d in directories if d.lower() not in EXCLUDED and not
            (getattr((Path(folder)/d).lstat(), 'st_file_attributes', 0) & 0x400) and not (Path(folder)/d).is_symlink()]
        for name in files:
            path = Path(folder)/name; rel = path.relative_to(root).as_posix()
            if allowed(rel):
                path = target(root, rel)
                if path.stat().st_size > MAX_FILE:
                    raise SyncError('Có file Data vượt 4 GB; chưa thể xác nhận đồng bộ toàn bộ.')
                if rel in CATALOGS:
                    data = normalized(rel, path.read_bytes()); sha = digest(data); size = len(data)
                else:
                    sha = hashlib.sha256()
                    with path.open('rb') as stream:
                        for block in iter(lambda: stream.read(1024**2), b''): sha.update(block)
                    sha = sha.hexdigest(); size = path.stat().st_size
                result[rel] = {'sha256': sha, 'bytes': size}
                if len(result) > 20000: raise SyncError('Kho Data vượt giới hạn đồng bộ của bản này.')
    return result

def merge_catalog(left, right):
    if left == right: return left
    if isinstance(left, dict) and isinstance(right, dict):
        value = dict(left)
        # Project tombstones survive old offline catalogs; explicit restore uses
        # its own newer clock. No source files are removed by this merge.
        project = str(left.get('id', right.get('id', ''))).startswith('prj_')
        visibility = project and ('visibilityChangedAt' in left or 'visibilityChangedAt' in right)
        for key, item in right.items():
            if visibility and key in ('archived', 'visibilityChangedAt'): continue
            if key not in value: value[key] = item
            elif project and key == 'name' and str(left.get('updatedAt', '')) != str(right.get('updatedAt', '')):
                value[key] = (right if str(right.get('updatedAt', '')) > str(left.get('updatedAt', '')) else left)[key]
            elif key == 'updatedAt': value[key] = max(str(value[key]), str(item))
            else: value[key] = merge_catalog(value[key], item)
        if visibility:
            stamp = max(str(left.get('visibilityChangedAt') or ''), str(right.get('visibilityChangedAt') or ''))
            owners = [v for v in (left, right) if str(v.get('visibilityChangedAt') or '') == stamp]
            value['visibilityChangedAt'] = stamp
            value['archived'] = any(v.get('archived') is True for v in owners)
        return value
    if isinstance(left, list) and isinstance(right, list):
        if not all(isinstance(x, dict) and isinstance(x.get('id'), str) for x in left + right):
            raise SyncError('Catalog có thay đổi cần xem lại.')
        items = {x['id']: x for x in left}
        for item in right:
            items[item['id']] = merge_catalog(items[item['id']], item) if item['id'] in items else item
        return [items[key] for key in sorted(items)]
    raise SyncError('Cùng nội dung đã được sửa trên hai máy; giữ cả hai bản.')


def merge_scripts(left, right):
    if (left.get('projectId') != right.get('projectId') or left.get('version') != 1 or right.get('version') != 1):
        raise SyncError('Bản nháp không cùng dự án hoặc phiên bản.')
    result = {'version': 1, 'projectId': left['projectId'], 'scripts': {}, 'effects': {}, 'modeSavedAt': {}}
    for mode in ('0', '1', '2'):
        a = str(left.get('modeSavedAt', {}).get(mode, left.get('savedAt', '')))
        b = str(right.get('modeSavedAt', {}).get(mode, right.get('savedAt', '')))
        for group in ('scripts', 'effects'):
            x, y = left.get(group, {}).get(mode), right.get(group, {}).get(mode)
            if x is None: chosen = y
            elif y is None or x == y: chosen = x
            elif a != b: chosen = x if a > b else y
            else: raise SyncError('Cùng mục kịch bản được sửa đồng thời; giữ hai bản.')
            if chosen is not None: result[group][mode] = chosen
        result['modeSavedAt'][mode] = max(a, b)
    result['savedAt'] = max(str(left.get('savedAt', '')), str(right.get('savedAt', '')))
    return result


def merge_photos(left, right):
    if (left.get('ownerKey') != right.get('ownerKey') or left.get('projectId') != right.get('projectId')):
        raise SyncError('Không gộp kho ảnh khác tài khoản hoặc sản phẩm.')
    result = dict(left)
    items = {p['id']: dict(p) for p in left.get('items', [])}
    for p in right.get('items', []):
        old = items.get(p['id'])
        if old is None: items[p['id']] = dict(p); continue
        for key in ('sha256', 'path', 'pixelSha256'):
            if old.get(key) != p.get(key): raise SyncError('Cùng mã ảnh có nguồn khác nhau; giữ hai bản.')
        if old != p:
            a, b = float(old.get('updatedAt', 0)), float(p.get('updatedAt', 0))
            if a != b: items[p['id']] = dict(p if b > a else old)
            else: raise SyncError('Cùng ảnh được sửa đồng thời; giữ hai bản.')
    result['items'] = [items[k] for k in sorted(items)]
    batches = {b['folder']: b for b in left.get('batches', [])}
    for b in right.get('batches', []): batches.setdefault(b['folder'], b)
    result['batches'] = sorted(batches.values(), key=lambda b: b.get('at', 0))
    newest = max((left, right), key=lambda v: float(v.get('updatedAt', 0)))
    for key in ('updatedAt', 'lastImport', 'lastAdded', 'lastDuplicateCount'):
        if key in newest: result[key] = newest[key]
    return result


def merge_metadata(relative, left, right):
    if relative in CATALOGS: return merge_catalog(left, right)
    if '/provided_photos/' in relative and relative.endswith('/library.json'): return merge_photos(left, right)
    if relative.endswith('/automatic_workspace/script_inputs.json'): return merge_scripts(left, right)
    raise SyncError('Chưa có cách gộp tự động loại Data này; giữ hai bản.')


def mergeable_metadata(relative):
    return (relative in CATALOGS or
            ('/provided_photos/' in relative and relative.endswith('/library.json')) or
            relative.endswith('/automatic_workspace/script_inputs.json'))


def recoverable_missing(relative):
    # App removal uses archived/removed tombstones. Missing originals are transport
    # damage or a different device cache, not permission to discard their cloud copy.
    return (Path(relative).suffix.lower() in {'.png', '.jpg', '.jpeg', '.webp', '.mp4', '.mov', '.wav', '.mp3', '.m4a'} or
            mergeable_metadata(relative))


def catalog_blocked(relative, blocked):
    """An unrelated conflict must not hide otherwise complete projects.

    Assets still precede their catalog, and a conflict/deferred file in that
    catalog's scope still prevents exposing a partial collection.
    """
    if relative == 'project_catalog.json':
        return relative in blocked
    if relative in CATALOGS:
        return any(p.startswith(('knowledge/', 'knowledge_inbox/')) or p == relative for p in blocked)
    return False

@contextmanager
def lock(root):
    import msvcrt
    path = root/'.sync'/'running.lock'; path.parent.mkdir(parents=True, exist_ok=True)
    stream = path.open('a+b'); stream.seek(0); stream.write(b'0'); stream.flush(); stream.seek(0)
    try:
        try: msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError: raise SyncError('Đang có một lượt đồng bộ Data.') from None
        yield
    finally:
        stream.close()

class DataSync:
    def __init__(self, root, cloud, subject):
        self.root, self.cloud, self.subject = root.absolute(), cloud, subject
        self.meta = self.root/'.sync'; self.meta.mkdir(parents=True, exist_ok=True)
        self.account_key = digest(subject.encode())
        binding = load(self.meta/'account.json', {})
        if binding.get('account') not in (None, self.account_key):
            raise SyncError('Kho Data này thuộc AI Video Studio khác. Giữ kho riêng trước khi đổi tài khoản.')
        atomic(self.meta/'account.json', {'account': self.account_key})
        self.state_path = self.meta/(self.account_key+'.json')
        self.state = load(self.state_path, {'device': uuid.uuid4().hex, 'baseline': {}})
        self.blobs = {f['appProperties']['key']: f['id'] for f in self.cloud.files('blob')}
        self.downloaded = 0; self.uploaded = 0

    def revisions(self):
        changes = {}; parents = set()
        for entry in self.cloud.files('commit'):
            cache = self.meta/'commits'/entry['id']; cache.parent.mkdir(parents=True, exist_ok=True)
            if not cache.exists():
                temporary = cache.with_name(cache.name+'.tmp')
                self.cloud.download(entry['id'], temporary, MAX_MANIFEST)
                load(temporary, {})
                os.replace(temporary, cache)
            value = load(cache, {})
            if value.get('schemaVersion') != 1 or value.get('applicationId') != APP or not isinstance(value.get('changes'), list):
                raise SyncError('Phiên bản Data trên cloud không hợp lệ.')
            for row in value['changes']:
                if (not isinstance(row, dict) or not allowed(row.get('path')) or
                    not re.fullmatch(r'[a-f0-9]{32}', str(row.get('id'))) or
                    not re.fullmatch(r'[a-f0-9]{64}', str(row.get('sha256'))) or
                    not isinstance(row.get('bytes'), int) or not 0 <= row['bytes'] <= MAX_FILE or
                    not isinstance(row.get('parents'), list) or len(row['parents']) > 1000 or
                    not all(re.fullmatch(r'[a-f0-9]{32}', str(p)) for p in row['parents']) or
                    not re.fullmatch(r'[A-Za-z0-9_-]{1,200}', str(row.get('blob')))):
                    raise SyncError('Bản ghi Data trên cloud không hợp lệ.')
                if row['id'] in changes and changes[row['id']] != row: raise SyncError('Bản ghi cloud trùng mã khác nội dung.')
                changes[row['id']] = row
        for row in changes.values():
            for parent in row['parents']:
                if parent not in changes or changes[parent]['path'] != row['path']:
                    raise SyncError('Lịch sử Data trên cloud chưa đầy đủ.')
                parents.add(parent)
        heads = {}
        for key, row in changes.items():
            if key not in parents: heads.setdefault(row['path'], []).append(row)
        return heads

    def blob(self, relative, content=None, expected=None):
        path = self.meta/'uploading'; path.parent.mkdir(parents=True, exist_ok=True)
        if content is None:
            original = target(self.root, relative)
            if relative in CATALOGS: path.write_bytes(normalized(relative, original.read_bytes()))
            else: shutil.copyfile(original, path)
        else: path.write_bytes(content)
        sha = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024**2), b''): sha.update(block)
        sha = sha.hexdigest()
        if expected and sha != expected: raise SyncError('Data đang thay đổi; sẽ đồng bộ lại khi máy rảnh.')
        if sha not in self.blobs:
            self.blobs[sha] = self.cloud.upload(path, 'blob', sha); self.uploaded += 1
        return {'sha256': sha, 'bytes': path.stat().st_size, 'blob': self.blobs[sha]}

    def publish(self, changes):
        if not changes: return
        for start in range(0, len(changes), 1000):
            path = self.meta/'publishing.json'
            atomic(path, {'schemaVersion': 1, 'applicationId': APP, 'device': self.state['device'], 'createdAt': utc(), 'changes': changes[start:start+1000]})
            if path.stat().st_size > MAX_MANIFEST: raise SyncError('Bản ghi Data vượt giới hạn.')
            self.cloud.upload(path, 'commit', digest(path.read_bytes()))

    def content(self, row):
        path = self.meta/'downloads'/row['sha256']; path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists(): self.cloud.download(row['blob'], path, row['bytes'])
        sha = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024**2), b''): sha.update(block)
        if path.stat().st_size != row['bytes'] or sha.hexdigest() != row['sha256']:
            path.unlink(missing_ok=True); raise SyncError('File cloud chưa đúng checksum; bản trên máy được giữ.')
        return path

    def apply(self, relative, row, expected):
        path = target(self.root, relative)
        current = snapshot_one(self.root, relative)
        if current != expected: raise SyncError('Data vừa thay đổi trên máy; chưa ghi đè, sẽ thử lại.')
        source = self.content(row)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            if relative in CATALOGS:
                value = load(source, {}); old = load(path, {})
                for key in ('activeProjectId', 'selectedId'):
                    if key in old: value[key] = old[key]
                temporary.write_bytes(encode(value))
            else: shutil.copyfile(source, temporary)
            if snapshot_one(self.root, relative) != expected: raise SyncError('Data đang thay đổi; giữ bản local.')
            os.replace(temporary, path); self.downloaded += 1
        finally: temporary.unlink(missing_ok=True)

    def run(self, stage_only=False):
        heads = self.revisions(); local = snapshot(self.root); baseline = self.state['baseline']; changes = []
        upload_deferred = []; upload_message = None
        for relative, info in local.items():
            observed = heads.get(relative, [])
            if any(row['sha256'] == info['sha256'] for row in observed): continue
            if baseline.get(relative, {}).get('sha256') == info['sha256']: continue
            if upload_message is not None:
                upload_deferred.append(relative); continue
            try:
                changes.append({'id': uuid.uuid4().hex, 'path': relative, **self.blob(relative, expected=info['sha256']),
                                'parents': baseline.get(relative, {}).get('heads', [])})
            except Exception as error:
                # A free write/storage limit must not prevent receiving Data
                # already stored by another device. Originals stay untouched.
                upload_deferred.append(relative); upload_message = str(error)
        try:
            self.publish(changes)
        except Exception as error:
            upload_deferred.extend(row['path'] for row in changes); upload_message = str(error)
        heads = self.revisions(); conflicts = []; deferred = []; pending = []; next_baseline = dict(baseline)
        # Assets precede catalogues so a catalog never exposes missing images.
        for relative in sorted(heads, key=lambda p: (p in CATALOGS, p)):
            rows = heads[relative]; info = local.get(relative); expected = info['sha256'] if info else None
            if relative in upload_deferred and info and not any(r['sha256'] == expected for r in rows):
                deferred.append(relative); continue
            hashes = {row['sha256'] for row in rows}; row = rows[0]
            if len(hashes) > 1:
                merged = None
                if mergeable_metadata(relative):
                    try:
                        for revision in rows:
                            value = load(self.content(revision), {})
                            merged = value if merged is None else merge_metadata(relative, merged, value)
                    except SyncError: merged = None
                if merged is not None:
                    try:
                        row = {'id': uuid.uuid4().hex, 'path': relative, **self.blob(relative, encode(merged)), 'parents': [r['id'] for r in rows]}
                        self.publish([row]); rows = [row]
                    except Exception as error:
                        deferred.append(relative); upload_deferred.append(relative)
                        upload_message = str(error); continue
                else:
                    conflicts.append(relative)
                    for revision in rows:
                        path = self.meta/'conflicts'/revision['id']/relative
                        path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(self.content(revision), path)
                    next_baseline[relative] = {'sha256': expected, 'heads': [r['id'] for r in rows if r['sha256'] == expected]}
                    continue
            if expected != row['sha256']:
                if catalog_blocked(relative, deferred + conflicts):
                    deferred.append(relative); continue
                # A local deletion is retained; no deletion is broadcast in v1.
                if info is None and relative in baseline and not recoverable_missing(relative):
                    deferred.append(relative); continue
                if stage_only:
                    self.content(row)
                    pending.append({'path': relative, 'row': row, 'expected': expected, 'heads': [r['id'] for r in rows]})
                    next_baseline[relative] = {'sha256': expected, 'heads': [r['id'] for r in rows if r['sha256'] == expected] or baseline.get(relative, {}).get('heads', [])}
                    continue
                try: self.apply(relative, row, expected)
                except SyncError: deferred.append(relative); continue
            next_baseline[relative] = {'sha256': row['sha256'], 'heads': [r['id'] for r in rows]}
        self.state['baseline'] = next_baseline; atomic(self.state_path, self.state)
        if stage_only:
            atomic(self.meta/'pending.json', {'account': self.account_key, 'changes': pending})
        result = {'phase': 'conflicts' if conflicts else 'deferred' if deferred or upload_deferred else 'pending' if pending else 'synced', 'checkedAt': utc(),
                  'uploaded': self.uploaded, 'downloaded': self.downloaded, 'conflictCount': len(conflicts), 'deferredCount': len(deferred),
                  'pendingCount': len(pending), 'conflicts': conflicts, 'deferred': deferred,
                  'uploadDeferredCount':len(set(upload_deferred)), 'uploadDeferred':sorted(set(upload_deferred)),
                  **({'message':upload_message} if upload_message else {}),
                  'account': self.account_key, 'provider': 'studio-account-data'}
        atomic(self.meta/'status.json', result)
        return result

def snapshot_one(root, relative):
    path = target(root, relative)
    if not path.is_file(): return None
    if relative in CATALOGS: return digest(normalized(relative, path.read_bytes()))
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''): sha.update(block)
    return sha.hexdigest()

def apply_pending(root, subject):
    task = DataSync.__new__(DataSync)
    task.root = root.absolute(); task.meta = root/'.sync'; task.cloud = None; task.downloaded = 0
    task.account_key = digest(subject.encode())
    pending = load(task.meta/'pending.json', {})
    if pending.get('account') != task.account_key:
        return {'phase': 'ready', 'downloaded': 0}
    if load(task.meta/'account.json', {}).get('account') != task.account_key:
        raise SyncError('Kho Data thuộc tài khoản khác; chưa áp dụng.')
    state_path = task.meta/(task.account_key+'.json'); state = load(state_path, {'baseline': {}})
    unresolved = []
    for change in pending.get('changes', []):
        relative, row = change['path'], change['row']
        if catalog_blocked(relative, [c['path'] for c in unresolved]):
            unresolved.append(change)
            continue
        try:
            if snapshot_one(root, relative) != row['sha256']:
                task.apply(relative, row, change['expected'])
            state['baseline'][relative] = {'sha256': row['sha256'], 'heads': change['heads']}
            atomic(state_path, state)
        except SyncError: unresolved.append(change)
    atomic(task.meta/'pending.json', {'account': task.account_key, 'changes': unresolved})
    result = load(task.meta/'status.json', {})
    result.update(phase='deferred' if unresolved or result.get('deferredCount') or result.get('uploadDeferredCount') else 'conflicts' if result.get('conflictCount') else 'synced',
                  pendingCount=len(unresolved), downloaded=task.downloaded, checkedAt=utc())
    atomic(task.meta/'status.json', result)
    return result

