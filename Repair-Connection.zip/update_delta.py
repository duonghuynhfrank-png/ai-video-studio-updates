"""Stage signed file changes and reuse independently verified local runtime files."""
import hashlib
import json
import os
from pathlib import Path
import re
import time
import zipfile

FORMAT = 'file-reuse-v1'
MAX_FILES = 30000
MAX_BYTES = 4 * 1024**3


class ReuseUnavailable(ValueError):
    """A required unchanged file is absent/corrupt; never silently fetch a full kit."""


def relative(value):
    if not isinstance(value, str):
        raise ValueError('Đường dẫn cập nhật không hợp lệ.')
    raw = value.replace('\\', '/')
    parts = raw.split('/')
    reserved = {'CON', 'PRN', 'AUX', 'NUL', *('COM'+str(i) for i in range(1,10)), *('LPT'+str(i) for i in range(1,10))}
    if (not raw or raw.startswith('/') or any(not p or p in ('.', '..') or ':' in p or
            p.endswith((' ', '.')) or p.split('.')[0].upper() in reserved for p in parts)):
        raise ValueError('Đường dẫn cập nhật không hợp lệ.')
    if parts[0].casefold() in {'models', 'projects', 'server-data', 'knowledge_bundle', '.release-signing'}:
        raise ValueError('Gói cập nhật không được ghi kho Data/model.')
    return raw


def no_links(path, checked):
    path = Path(path)
    trail = []
    while path != path.parent and path not in checked:
        if path.is_symlink() or path.is_junction():
            raise ValueError('Không cập nhật qua đường dẫn liên kết.')
        trail.append(path)
        path = path.parent
    checked.update(trail)


def extract_changes(archive, destination, release, reuse_from, progress=None,
                    max_seconds=600, resume=False, stats=None):
    started = time.monotonic()
    destination, base = Path(destination).absolute(), Path(reuse_from).absolute()
    if (destination == base or destination.is_relative_to(base) or base.is_relative_to(destination)):
        raise ValueError('Bản mới phải ở thư mục riêng, không ghi phiên bản đang dùng.')
    checked = set()
    no_links(base, checked)
    no_links(destination, checked)
    if not resume and destination.exists() and any(destination.iterdir()):
        raise ValueError('Bản mới phải dùng thư mục trống.')
    done = count = 0
    totals = [0, 0]
    metrics = {'reusedFiles': 0, 'reusedBytes': 0, 'changedFiles': 0, 'writtenBytes': 0,
               'copiedBytes': 0, 'linkedFiles': 0}

    def pulse(extra=0):
        if time.monotonic() - started > max_seconds:
            raise TimeoutError('Chuẩn bị bản cập nhật quá thời gian; giữ tiến độ để tiếp tục.')
        if progress:
            progress(done + extra, totals[0], count, totals[1])

    def checked_hash(path):
        value = hashlib.sha256()
        amount = 0
        with path.open('rb') as stream:
            while chunk := stream.read(1024**2):
                value.update(chunk)
                amount += len(chunk)
                pulse(amount)
        return value.hexdigest()

    with zipfile.ZipFile(archive) as source:
        entries = {}
        for item in source.infolist():
            name = relative(item.filename.rstrip('/'))
            key = name.casefold()
            if key in entries or ((item.external_attr >> 16) & 0o170000) == 0o120000 or item.is_dir():
                raise ValueError('Gói thay đổi có file trùng/thư mục hoặc liên kết.')
            entries[key] = item
        if len(entries) > MAX_FILES or sum(i.file_size for i in entries.values()) > MAX_BYTES:
            raise ValueError('Gói thay đổi quá lớn.')
        manifest_entry = entries.pop('package-manifest.json', None)
        if manifest_entry is None or manifest_entry.file_size > 16 * 1024**2:
            raise ValueError('Gói thay đổi thiếu manifest hợp lệ.')
        manifest_raw = source.read(manifest_entry)
        manifest_sha = hashlib.sha256(manifest_raw).hexdigest()
        if manifest_sha != release['changes']['manifestSha256']:
            raise ValueError('Manifest không khớp bản phát hành có chữ ký.')
        manifest = json.loads(manifest_raw.decode('utf-8-sig'))
        if (manifest.get('schemaVersion') != 1 or manifest.get('target') != 'windows-x64' or
                manifest.get('version') != release['version'] or
                manifest.get('sourceFingerprint', '') != release.get('sourceFingerprint', '')):
            raise ValueError('Manifest không khớp bản phát hành có chữ ký.')
        files = manifest.get('files')
        if not isinstance(files, list) or not 8 <= len(files) <= MAX_FILES:
            raise ValueError('Danh sách file cập nhật không hợp lệ.')
        recorded = {}
        for file in files:
            name = relative(file['path'])
            key = name.casefold()
            if (key in recorded or key == 'package-manifest.json' or
                    type(file.get('bytes')) is not int or file['bytes'] < 0 or
                    not isinstance(file.get('sha256'), str) or not re.fullmatch('[a-f0-9]{64}', file['sha256'])):
                raise ValueError('Manifest có file trùng hoặc checksum/kích thước sai.')
            recorded[key] = {**file, 'path': name}
        required = {'ai_video_studio.exe', 'flutter_windows.dll', 'data/app.so', '.installed',
                    'maintenance/launch.ps1', 'maintenance/update.common.ps1',
                    'maintenance/uninstall.ps1', 'maintenance/rollback.ps1'}
        if not required.issubset(recorded) or not entries.keys() <= recorded.keys():
            raise ValueError('Manifest thiếu runtime hoặc gói có file ngoài manifest.')
        totals[:] = [sum(f['bytes'] for f in files), len(files)]
        if totals[0] > MAX_BYTES:
            raise ValueError('Bản cập nhật quá lớn.')
        for key, entry in entries.items():
            if entry.file_size != recorded[key]['bytes']:
                raise ValueError('File thay đổi sai kích thước.')
        allowed = set(recorded) | {'package-manifest.json'}
        if resume and destination.exists():
            for folder, directories, names in os.walk(destination, followlinks=False):
                for name in directories + names:
                    path = Path(folder) / name
                    if path.is_symlink() or path.is_junction():
                        raise ValueError('Không tiếp tục qua đường dẫn liên kết.')
                    if path.is_file() and path.relative_to(destination).as_posix().casefold() not in allowed:
                        raise ValueError('Bản đang chuẩn bị có file ngoài manifest.')
        manifest_path = destination / 'package-manifest.json'
        if manifest_path.exists() and manifest_path.read_bytes() != manifest_raw:
            raise ValueError('Manifest bản đang chuẩn bị đã đổi.')
        pulse()
        for key, file in recorded.items():
            target = destination / file['path']
            no_links(target, checked)
            target.parent.mkdir(parents=True, exist_ok=True)
            if (resume and target.is_file() and target.stat().st_size == file['bytes'] and
                    checked_hash(target) == file['sha256']):
                done += file['bytes']
                count += 1
                pulse()
                continue
            if target.exists():
                # An earlier candidate may hard-link a previous generation.
                # Unlink before replacement, never truncate a shared inode.
                target.unlink()
            if key in entries:
                value = hashlib.sha256()
                amount = 0
                with source.open(entries[key]) as incoming, target.open('xb') as output:
                    while chunk := incoming.read(1024**2):
                        value.update(chunk)
                        output.write(chunk)
                        amount += len(chunk)
                        pulse(amount)
                if value.hexdigest() != file['sha256']:
                    raise ValueError('File thay đổi sai checksum: ' + file['path'])
                metrics['changedFiles'] += 1
                metrics['writtenBytes'] += file['bytes']
            else:
                original = base / file['path']
                no_links(original, checked)
                if (not original.is_file() or original.stat().st_size != file['bytes'] or
                        checked_hash(original) != file['sha256']):
                    raise ReuseUnavailable('Thư viện cục bộ thiếu hoặc khác bản: ' + file['path'] +
                        '. Đã giữ app/Data; không tự tải lại bộ thư viện đầy đủ.')
                try:
                    os.link(original, target)
                    metrics['linkedFiles'] += 1
                except OSError:
                    # Filesystems without hard links still receive only changes;
                    # copying is local and never overwrites the active version.
                    value, amount = hashlib.sha256(), 0
                    with original.open('rb') as incoming, target.open('xb') as output:
                        while chunk := incoming.read(1024**2):
                            output.write(chunk)
                            value.update(chunk)
                            amount += len(chunk)
                            pulse(amount)
                    if value.hexdigest() != file['sha256']:
                        raise ReuseUnavailable('File thư viện đã thay đổi khi sao chép: ' + file['path'])
                    metrics['copiedBytes'] += file['bytes']
                metrics['reusedFiles'] += 1
                metrics['reusedBytes'] += file['bytes']
            done += file['bytes']
            count += 1
            pulse()
        if not manifest_path.exists():
            with manifest_path.open('xb') as output:
                output.write(manifest_raw)
    if stats is not None:
        stats.update(metrics)
    return manifest_sha
