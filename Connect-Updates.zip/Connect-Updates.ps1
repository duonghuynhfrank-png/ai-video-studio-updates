﻿param([string]$InstallRoot='', [switch]$ConfigureOnly)
$ErrorActionPreference='Stop'
$feed='https://github.com/duonghuynhfrank-png/ai-video-studio-updates/releases/latest/download/latest.json'
$publisherKey=@'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAn7MEucFv2WShwBKS5bgT
mUwwyoBjXhKK9tD5UKVjSXGB7+qTex+HQxuv0uJ/7zgLz5VynRebPn5JTronvqkN
wTDiGOzFrAwZ9JRNtiLzyDc4jN9Rh+tt6pT3AwsAp7kQG8Gefaa2OP9II4EKvj5H
iKGEeA8IO5jwiuh7CQYYLWPepCzv0Yjvy32863aRh2ZS5dHFRxuIxlqd4kIye4fT
XieL+yppqSH0gcd/HurP9NqCrcbTqwwENVbYm2f4EgZZXghryMnL9GPH2zyGh0uz
ILirKXv+uLNBXzB29bQckUKm98RyeVWAPjhwd9nMJYWjBFMJ9C714nXjtUQ5lK66
o7muSb1vmNnSeV4Ry/AD2xXO+uyL8WbdHyzy8Z6X76JuKQ5E2ta0NngpNTgPvNk1
VRwl1F5H3dlCozbXdVhfRD5b0N1yQNXxac49dyOsfv33TfThfeZNqbO31d1uWw6r
U81f2VqdL7wPVpUy5BzE0wG3kJm60zKKeh75alPk8fvpAgMBAAE=
-----END PUBLIC KEY-----
'@
if(-not $InstallRoot){$InstallRoot=(Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIVideoStudioLocal' -ErrorAction SilentlyContinue).InstallLocation}
if(-not $InstallRoot){$InstallRoot=Join-Path $env:LOCALAPPDATA 'Programs\AI Video Studio'}
$root=[IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
function Assert-Unlinked([string]$Path){
  $cursor=[IO.Path]::GetFullPath($Path)
  while($cursor){
    try{$attributes=[IO.File]::GetAttributes($cursor)}catch [IO.FileNotFoundException]{$attributes=0}catch [IO.DirectoryNotFoundException]{$attributes=0}
    if($attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Không ghi cấu hình qua đường dẫn liên kết.'}
    $cursor=[IO.Path]::GetDirectoryName($cursor)
  }
}
Assert-Unlinked $root
$trustFile=Join-Path $root 'update-trust.json'
if(-not(Test-Path -LiteralPath $trustFile)){throw 'Chưa tìm thấy AI Video Studio đã cài trên máy này.'}
$trust=Get-Content -LiteralPath $trustFile -Raw -Encoding UTF8 | ConvertFrom-Json
if($trust.applicationId -ne 'vn.aivideostudio' -or ($trust.publicKeyPem -replace '\s','') -ne ($publisherKey -replace '\s','')){throw 'Khóa nhà phát hành không khớp. Không thay đổi bản app hiện tại.'}
$updates=Join-Path $root 'updates';[IO.Directory]::CreateDirectory($updates) | Out-Null
$client=Join-Path $updates 'client.json'
Assert-Unlinked $client
$newSettings=@{schemaVersion=1;feedUrl=$feed} | ConvertTo-Json
[IO.File]::WriteAllText(($client+'.new'),$newSettings,[Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath ($client+'.new') -Destination $client -Force
Write-Output 'Đã kết nối dịch vụ cập nhật chung. Các lần sửa code tiếp theo sẽ được nhận tự động.'
if($ConfigureOnly){return}
$info=Get-Content -LiteralPath (Join-Path $root 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if([IO.Path]::IsPathRooted($info.current)){
  if((Split-Path (Split-Path $info.current -Parent) -Leaf) -ne 'versions'){throw 'Thư mục bản đã cài không hợp lệ.'}
  $current=Join-Path (Join-Path $root 'versions') (Split-Path $info.current -Leaf)
}else{$current=[IO.Path]::GetFullPath((Join-Path $root $info.current))}
if(-not $current.StartsWith(($root+'\versions\'),[StringComparison]::OrdinalIgnoreCase)){throw 'Thư mục bản đã cài không hợp lệ.'}
$python=Join-Path $current 'python\python.exe'
$updater=Join-Path $current 'python\update_client.py'
if(-not(Test-Path -LiteralPath $updater)){throw 'Bản này thiếu bộ nhận cập nhật; cần cài bản Windows mới một lần.'}
Write-Output 'Đang tải và xác minh bản mới nhất…'
& $python $updater stage --root $root
if($LASTEXITCODE -ne 0){throw 'Chưa tải được bản mới. Kết nối đã lưu, hệ thống sẽ thử lại khi có mạng.'}
$app=Get-Process ai_video_studio -ErrorAction SilentlyContinue | Where-Object {$_.Path -and $_.Path.StartsWith(($root+'\'),[StringComparison]::OrdinalIgnoreCase)}
if($app){Write-Output 'Bản mới đã sẵn sàng. Với bản cũ chưa biết tự khởi động lại, đóng và mở ứng dụng một lần để áp dụng.'}
else{Start-Process -FilePath (Join-Path $root 'AI Video Studio.exe') -WindowStyle Normal}
