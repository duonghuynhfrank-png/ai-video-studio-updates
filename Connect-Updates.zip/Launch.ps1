﻿param([switch]$UninstallOnly)
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
. (Join-Path $root 'Update.Common.ps1')
function Repair-Uninstaller($Info){
  $source=Join-Path $Info.current 'maintenance\Uninstall.exe'
  $target=Join-Path $root 'Uninstall.exe'
  if((Test-Path -LiteralPath $source) -and (-not(Test-Path -LiteralPath $target) -or (Get-Hash $source) -ne (Get-Hash $target))){Copy-Item -LiteralPath $source -Destination $target -Force}
  Save-InstallInfo $root $Info
}
$activation=New-Object Threading.Mutex($false,(Activation-MutexName $root))
$owns=$false
try{
  # A source watcher is installed only on the development computer.
  $config=Join-Path (Split-Path $root -Parent) 'local-system.json'
  $developmentIni=Join-Path $root 'development.ini'
  if(Test-Path -LiteralPath $developmentIni){
    foreach($line in Get-Content -LiteralPath $developmentIni -Encoding Unicode){if($line -match '^Config=(.+)$'){$config=$Matches[1];break}}
  }
  if(Test-Path -LiteralPath $config){
    $settings=Get-Content -LiteralPath $config -Raw -Encoding UTF8 | ConvertFrom-Json
    $watch=Join-Path $settings.development 'scripts\Watch-LocalUpdates.ps1'
    if(Test-Path -LiteralPath $watch){& schtasks.exe /Run /TN 'AI Video Studio Code Updates' *> $null}
  }
  $background=Join-Path $root 'Register-BackgroundUpdates.ps1'
  if(Test-Path -LiteralPath $background){
    try{& $background -InstallRoot $root -StartNow}catch{Write-JsonAtomic (Join-Path $root 'updates\background-install-error.json') @{message=$_.Exception.Message}}
  }
  # Verification may still own the gate on a slower PC. Wait for its result.
  try{$owns=$activation.WaitOne(1200000)}catch [Threading.AbandonedMutexException]{$owns=$true}
  if(-not $owns){throw 'Another update is being activated. Try opening the app again shortly.'}
  if($UninstallOnly){
    $info=Get-InstallInfo $root;Repair-Uninstaller $info
    if(-not(Test-Path -LiteralPath (Join-Path $root 'Uninstall.exe'))){throw 'Thiếu trình gỡ cài đặt trong bản cập nhật.'}
    Start-Process -FilePath (Join-Path $root 'Uninstall.exe') -WindowStyle Hidden
    exit 0
  }
  $inUse=Get-Process ai_video_studio,sd-cli,sd-server,llama-server -ErrorAction SilentlyContinue | Where-Object{$_.Path -and $_.Path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)}
  if(-not $inUse){
    try{[void](Activate-Pending $root)}catch{
      [IO.Directory]::CreateDirectory((Join-Path $root 'updates')) | Out-Null
      [IO.File]::WriteAllText((Join-Path $root 'updates\activation-error.txt'),$_.Exception.Message,[Text.UTF8Encoding]::new($false))
    }
  }
  $info=Get-InstallInfo $root
  Repair-Uninstaller $info
  $already=Get-Process ai_video_studio -ErrorAction SilentlyContinue | Where-Object {$_.Path -eq (Join-Path $info.current 'ai_video_studio.exe')}
  if($settings -and $settings.runtimeRoot){$already=Get-Process ai_video_studio -ErrorAction SilentlyContinue}
  if($already){exit 0}
  $workingDirectory=$info.current
  if($settings -and $settings.runtimeRoot){
    $workingDirectory=$settings.runtimeRoot
    $accountStartup=Join-Path $settings.development 'scripts\Start-AccountServer.ps1'
    if(Test-Path -LiteralPath $accountStartup){& $accountStartup -Config $config}
  }
  $app=Start-Process -FilePath (Join-Path $info.current 'ai_video_studio.exe') -WorkingDirectory $workingDirectory -WindowStyle Normal -PassThru
  Start-Sleep -Seconds 4;$app.Refresh()
  if($app.HasExited -and $app.ExitCode -ne 0 -and $info.previous){
    $failed=$info.current;$info.current=$info.previous;$info.previous=$failed
    $info.version=(Get-Content -LiteralPath (Join-Path $info.current 'package-manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
    Save-InstallInfo $root $info
    Start-Process -FilePath (Join-Path $info.current 'ai_video_studio.exe') -WorkingDirectory $workingDirectory -WindowStyle Normal
    [IO.File]::WriteAllText((Join-Path $root 'updates\activation-error.txt'),'New app failed at startup. Previous version restored.')
  }
  if(-not $app.HasExited){
    try{[void](Prune-Versions $root)}
    catch{Write-JsonAtomic (Join-Path $root 'updates\cleanup-error.json') @{message=$_.Exception.Message}}
  }
}catch{
  Add-Type -AssemblyName PresentationFramework
  [void][Windows.MessageBox]::Show($_.Exception.Message,'AI Video Studio - launch error','OK','Error')
  exit 1
}finally{if($owns){$activation.ReleaseMutex()};$activation.Dispose()}
