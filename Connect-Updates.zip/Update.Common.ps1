﻿$ErrorActionPreference='Stop'
function Activation-MutexName([string]$Root){
  $rootPath=[IO.Path]::GetFullPath($Root).TrimEnd('\')
  $development=Join-Path (Split-Path $rootPath -Parent) 'local-system.json'
  if(Test-Path -LiteralPath $development){
    $settings=Get-Content -LiteralPath $development -Raw -Encoding UTF8 | ConvertFrom-Json
    if([IO.Path]::GetFullPath($settings.installRoot).TrimEnd('\') -eq $rootPath){return 'Local\AIVideoStudioActivation'}
  }
  $hash=[Security.Cryptography.SHA256]::Create()
  try{return 'Local\AIVideoStudioActivation'+[BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($rootPath.ToLowerInvariant()))).Replace('-','')}
  finally{$hash.Dispose()}
}
function Write-JsonAtomic([string]$Path,$Value){
  $temp=$Path+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
  [IO.File]::WriteAllText($temp,($Value | ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
  if(Test-Path -LiteralPath $Path){
    $backup=$Path+'.replace-backup-'+[Guid]::NewGuid().ToString('N')
    [IO.File]::Replace($temp,$Path,$backup)
    [IO.File]::Delete($backup)
  }else{[IO.File]::Move($temp,$Path)}
}
function Get-Hash([string]$Path){
  $stream=[IO.File]::OpenRead($Path);$hasher=[Security.Cryptography.SHA256]::Create()
  try{return [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}
  finally{$stream.Dispose();$hasher.Dispose()}
}
function Assert-Child([string]$Path,[string]$Root){
  $full=[IO.Path]::GetFullPath($Path);$base=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
  if(-not $full.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){throw "Path outside expected directory: $full"}
  $cursor=$full
  while($cursor.Length -ge $base.TrimEnd('\').Length){
    try{$attributes=[IO.File]::GetAttributes($cursor)}
    catch [IO.FileNotFoundException]{$attributes=0}
    catch [IO.DirectoryNotFoundException]{$attributes=0}
    if($attributes -band [IO.FileAttributes]::ReparsePoint){throw "Linked update path rejected: $cursor"}
    $cursor=[IO.Path]::GetDirectoryName($cursor)
  }
  return $full
}
function Get-InstallInfo([string]$Root){
  $file=Join-Path $Root 'installation.json'
  $info=Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach($field in @('current','previous')){
    if($info.$field){
      $raw=[string]$info.$field
      if([IO.Path]::IsPathRooted($raw)){
        # Allow a complete installed folder copied to a different PC/drive.
        $leaf=[IO.Path]::GetFileName($raw.TrimEnd('\'))
        if([IO.Path]::GetFileName([IO.Path]::GetDirectoryName($raw)) -ne 'versions'){throw 'Invalid version location.'}
        $info.$field=Assert-Child (Join-Path (Join-Path $Root 'versions') $leaf) (Join-Path $Root 'versions')
      }else{$info.$field=Assert-Child (Join-Path $Root $raw) (Join-Path $Root 'versions')}
    }
  }
  $info.models=Join-Path $Root 'models'
  if(-not (Test-Path -LiteralPath (Join-Path $info.current 'ai_video_studio.exe'))){throw 'Application files are missing. Copy the whole app folder or use the Setup installer.'}
  return $info
}
function Save-InstallInfo([string]$Root,$Info){
  $copy=$Info | ConvertTo-Json -Depth 8 | ConvertFrom-Json
  foreach($field in @('current','previous')){if($copy.$field){$copy.$field=$copy.$field.Substring($Root.TrimEnd('\').Length+1)}}
  $copy.models='models'
  Write-JsonAtomic (Join-Path $Root 'installation.json') $copy
  $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIVideoStudioLocal'
  $registered=Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
  if($registered.InstallLocation -and [IO.Path]::GetFullPath($registered.InstallLocation).TrimEnd('\') -eq [IO.Path]::GetFullPath($Root).TrimEnd('\')){
    if(Test-Path -LiteralPath (Join-Path $Root 'Uninstall.exe')){New-ItemProperty -Path $key -Name UninstallString -Value ('"'+(Join-Path $Root 'Uninstall.exe')+'"') -PropertyType String -Force | Out-Null}
    New-ItemProperty -Path $key -Name DisplayVersion -Value $Info.version -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name DisplayIcon -Value (Join-Path $Info.current 'ai_video_studio.exe') -PropertyType String -Force | Out-Null
  }
}
function Assert-Idle([string]$Root=$PSScriptRoot){
  $prefix=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
  # Development previews use the same data even when their EXE lives elsewhere.
  $development=Join-Path (Split-Path $Root -Parent) 'local-system.json'
  $sharedRuntime=$null
  if(Test-Path -LiteralPath $development){
    $settings=Get-Content -LiteralPath $development -Raw -Encoding UTF8 | ConvertFrom-Json
    if([IO.Path]::GetFullPath($settings.installRoot).TrimEnd('\') -eq [IO.Path]::GetFullPath($Root).TrimEnd('\')){$sharedRuntime=[IO.Path]::GetFullPath($settings.runtimeRoot).TrimEnd('\')+'\'}
  }
  $running=Get-Process ai_video_studio,sd-cli,sd-server,llama-server,ffmpeg,whisper-cli -ErrorAction SilentlyContinue
  if($sharedRuntime -and @($running | Where-Object ProcessName -eq 'ai_video_studio').Count){throw 'The development app is open; the verified update will apply after it closes.'}
  foreach($job in Get-CimInstance Win32_Process -Filter "Name = 'python.exe'"){
    if($job.ExecutablePath -and ($job.ExecutablePath.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or ($sharedRuntime -and $job.ExecutablePath.StartsWith($sharedRuntime,[StringComparison]::OrdinalIgnoreCase))) -and $job.CommandLine -match 'voice_studio.py|synthesize_vietnamese.py|transcribe_reference.py|native_ocr.py|product_camera.py|product_3d.py'){throw 'A local AI job is running; activation is deferred until it finishes.'}
  }
  foreach($process in $running){
    try{$path=$process.Path}catch{throw 'Cannot verify the running AI process. Close its app before updating.'}
    if($path -and ($path.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or ($sharedRuntime -and $path.StartsWith($sharedRuntime,[StringComparison]::OrdinalIgnoreCase)))){throw 'Save and close this AI Video Studio and its AI jobs before activating the update.'}
  }
}
function Prune-Versions([string]$Root){
  $publisher=New-Object Threading.Mutex($false,'Local\AIVideoStudioLocalPublish');$ownsPublisher=$false
  try{
  try{$ownsPublisher=$publisher.WaitOne(0)}catch [Threading.AbandonedMutexException]{$ownsPublisher=$true}
  if(-not $ownsPublisher){return @{removed=@();deferred='A local update is being prepared.'}}
  $rootPath=[IO.Path]::GetFullPath($Root).TrimEnd('\')
  $versions=Assert-Child (Join-Path $rootPath 'versions') $rootPath
  $info=Get-InstallInfo $rootPath
  $keep=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
  [void]$keep.Add($info.current)
  if($info.previous){[void]$keep.Add($info.previous)}
  $pending=Join-Path $rootPath 'updates\pending.json'
  if(Test-Path -LiteralPath $pending){$candidate=(Get-Content -LiteralPath $pending -Raw -Encoding UTF8 | ConvertFrom-Json).candidate;[void]$keep.Add((Assert-Child (Join-Path $rootPath $candidate) $versions))}
  foreach($process in Get-Process ai_video_studio,sd-cli,sd-server,llama-server,ffmpeg,whisper-cli,python -ErrorAction SilentlyContinue){
    try{$path=$process.Path}catch{return @{removed=@();deferred='Running process access unavailable'}}
    if($path -and $path.StartsWith($versions+'\',[StringComparison]::OrdinalIgnoreCase)){
      $leaf=$path.Substring($versions.Length+1).Split('\')[0]
      [void]$keep.Add((Join-Path $versions $leaf))
    }
  }
  $removed=@();$deferred=@()
  foreach($directory in Get-ChildItem -LiteralPath $versions -Directory -Force){
    $checked=Assert-Child $directory.FullName $versions
    if($keep.Contains($checked)){continue}
    if(-not(Test-Path -LiteralPath (Join-Path $checked 'package-manifest.json')) -or -not(Test-Path -LiteralPath (Join-Path $checked '.installed'))){$deferred+=$checked;continue}
    if(Get-ChildItem -LiteralPath $checked -Recurse -Force | Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}){$deferred+=$checked;continue}
    Remove-Item -LiteralPath $checked -Recurse -Force
    $removed+=$checked
  }
  $result=@{removed=$removed;kept=$keep.Count;deferred=$deferred;policy='current + one rollback + pending while staging';at=[DateTime]::UtcNow.ToString('o')}
  [IO.Directory]::CreateDirectory((Join-Path $rootPath 'updates')) | Out-Null
  Write-JsonAtomic (Join-Path $rootPath 'updates\retention.json') $result
  return $result
  }finally{if($ownsPublisher){$publisher.ReleaseMutex()};$publisher.Dispose()}
}
function Verify-Version([string]$VersionRoot,[string]$ExpectedVersion){
  $manifest=Get-Content -LiteralPath (Join-Path $VersionRoot 'package-manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  if($manifest.schemaVersion -ne 1 -or $manifest.version -ne $ExpectedVersion -or $manifest.target -ne 'windows-x64'){throw 'Invalid update manifest.'}
  if($manifest.files.Count -lt 5){throw 'Incomplete update.'}
  $seen=@{}
  foreach($f in $manifest.files){
    if([IO.Path]::IsPathRooted($f.path) -or $f.path -match '(^|[\\/])\.\.([\\/]|$)' -or $f.path.Contains(':')){throw 'Invalid manifest path.'}
    if($seen.ContainsKey($f.path)){throw 'Duplicate manifest path.'};$seen[$f.path]=$true
    $path=Assert-Child (Join-Path $VersionRoot $f.path) $VersionRoot
    if(-not [IO.File]::Exists($path) -or [IO.FileInfo]::new($path).Length -ne $f.bytes){throw "Incomplete file: $($f.path)"}
    if((Get-Hash $path) -ne $f.sha256){throw "Checksum failed: $($f.path)"}
  }
  foreach($required in @('ai_video_studio.exe','flutter_windows.dll','data/app.so','.installed')){
    if(-not $seen.ContainsKey($required)){throw "Missing runtime: $required"}
  }
  return $manifest
}
function Activate-Pending([string]$Root){
  $pending=Join-Path $Root 'updates\pending.json'
  if(-not (Test-Path -LiteralPath $pending)){return $false}
  Assert-Idle $Root
  $request=Get-Content -LiteralPath $pending -Raw -Encoding UTF8 | ConvertFrom-Json
  $candidate=Assert-Child (Join-Path $Root $request.candidate) (Join-Path $Root 'versions')
  $manifestPath=Join-Path $candidate 'package-manifest.json'
  if((Get-Hash $manifestPath) -ne $request.manifestSha256){throw 'Pending update manifest changed.'}
  $manifest=Verify-Version $candidate $request.version
  foreach($name in @('Launch.ps1','Rollback.ps1','Uninstall.ps1','Update.Common.ps1')){
    $script=Join-Path $candidate ('maintenance\'+$name)
    $tokens=$null;$errors=$null
    [Management.Automation.Language.Parser]::ParseFile($script,[ref]$tokens,[ref]$errors) | Out-Null
    if($errors.Count){throw "Invalid maintenance script: $name"}
  }
  $info=Get-InstallInfo $Root
  if($info.current -ne $candidate){
    foreach($name in @('Launch.ps1','Rollback.ps1','Uninstall.ps1','Update.Common.ps1')){Copy-Item -LiteralPath (Join-Path $candidate ('maintenance\'+$name)) -Destination (Join-Path $Root $name) -Force}
    foreach($name in @('Background-Update.ps1','Register-BackgroundUpdates.ps1')){
      $script=Join-Path $candidate ('maintenance\'+$name)
      if(Test-Path -LiteralPath $script){Copy-Item -LiteralPath $script -Destination (Join-Path $Root $name) -Force}
    }
    $restart=Join-Path $candidate 'maintenance\Restart-Update.ps1'
    if(Test-Path -LiteralPath $restart){Copy-Item -LiteralPath $restart -Destination (Join-Path $Root 'Restart-Update.ps1') -Force}
    $native=Join-Path $candidate 'maintenance\AI Video Studio.exe'
    $target=Join-Path $Root 'AI Video Studio.exe'
    if((Test-Path -LiteralPath $native) -and (-not (Test-Path -LiteralPath $target) -or (Get-Hash $native) -ne (Get-Hash $target))){Copy-Item -LiteralPath $native -Destination $target -Force}
    $uninstaller=Join-Path $candidate 'maintenance\Uninstall.exe'
    if(Test-Path -LiteralPath $uninstaller){Copy-Item -LiteralPath $uninstaller -Destination (Join-Path $Root 'Uninstall.exe') -Force}
    $trust=Join-Path $candidate 'maintenance\update-trust.json'
    if(Test-Path -LiteralPath $trust){Copy-Item -LiteralPath $trust -Destination (Join-Path $Root 'update-trust.json') -Force}
    $info.previous=$info.current;$info.current=$candidate;$info.version=$request.version
    if($request.releaseSequence){$info | Add-Member -NotePropertyName releaseSequence -NotePropertyValue $request.releaseSequence -Force}
    Save-InstallInfo $Root $info
    $background=Join-Path $Root 'Register-BackgroundUpdates.ps1'
    if(Test-Path -LiteralPath $background){
      try{& $background -InstallRoot $Root}catch{Write-JsonAtomic (Join-Path $Root 'updates\background-install-error.json') @{message=$_.Exception.Message}}
    }
  }
  Move-Item -LiteralPath $pending -Destination (Join-Path $Root 'updates\last-applied.json') -Force
  Write-JsonAtomic (Join-Path $Root 'updates\status.json') @{phase='applied';version=$request.version;at=[DateTime]::UtcNow.ToString('o');sourceFingerprint=$request.sourceFingerprint}
  return $true
}
function Source-Fingerprint([string]$Source){
  $selected=New-Object 'Collections.Generic.List[string]'
  foreach($name in @('lib','windows','ios','assets','gateway','accounts_server')){
    $dir=Join-Path $Source $name
    if(Test-Path -LiteralPath $dir){
      Get-ChildItem -LiteralPath $dir -Recurse -File -Force | Where-Object {
        $_.FullName -notmatch '[\\/]ephemeral[\\/]|[\\/]\.plugin_symlinks[\\/]|[\\/]\.git[\\/]|[\\/]__pycache__[\\/]' -and $_.Extension -ne '.pyc' -and $_.Name -notin @('knowledge_catalog.json','seed_snapshot.json')
      } | ForEach-Object{$selected.Add($_.FullName)}
    }
  }
  foreach($name in @('pubspec.yaml','pubspec.lock')){if(Test-Path -LiteralPath (Join-Path $Source $name)){$selected.Add((Join-Path $Source $name))}}
  $python=Join-Path $Source 'third_party\python\windows-x64'
  if(Test-Path -LiteralPath $python){Get-ChildItem -LiteralPath $python -File | Where-Object{$_.Extension -in @('.py','.json','._pth')} | ForEach-Object{$selected.Add($_.FullName)}}
  $geometrySource=Join-Path $python 'three_d_source'
  if(Test-Path -LiteralPath $geometrySource){Get-ChildItem -LiteralPath $geometrySource -Recurse -File -Filter '*.py' | ForEach-Object{$selected.Add($_.FullName)}}
  $development=if(Test-Path -LiteralPath (Join-Path $Source 'Development')){Join-Path $Source 'Development'}else{Join-Path (Split-Path $Source -Parent) 'Development'}
  foreach($folder in @('scripts','packaging')){
    $directory=Join-Path $development $folder
    if(Test-Path -LiteralPath $directory){Get-ChildItem -LiteralPath $directory -File | Where-Object {$_.Extension -in @('.py','.ps1','.cpp','.h','.cmd','.ini')} | ForEach-Object {if(-not $selected.Contains($_.FullName)){$selected.Add($_.FullName)}}}
  }
  foreach($relative in @('packaging\Launch.ps1','packaging\Update.Common.ps1','packaging\Rollback.ps1','packaging\Uninstall.ps1','scripts\Publish-LocalUpdate.ps1','scripts\Watch-LocalUpdates.ps1','packaging\app_launcher.cpp','scripts\build_launcher.ps1','scripts\Publish-Release.ps1','scripts\publish_release.py','scripts\release_io.py','scripts\build_package.ps1','scripts\build_setup.ps1','packaging\Install.ps1','packaging\setup_stub.cpp','packaging\update-trust.json','packaging\uninstaller.cpp','scripts\build_uninstaller.ps1','scripts\build_offline_media.ps1','scripts\Build-Development.ps1','scripts\Publish-CodeUpdate.ps1','scripts\Start-SourcePublisher.ps1','scripts\Bootstrap-DevelopmentApp.ps1','scripts\Start-AccountServer.ps1','scripts\check_server_store.py')){
    $file=Join-Path $development $relative
    if((Test-Path -LiteralPath $file) -and -not $selected.Contains($file)){$selected.Add($file)}
  }
  $text=(@($selected | Sort-Object | ForEach-Object{$_+' '+(Get-Hash $_)}) -join "`n")
  $h=[Security.Cryptography.SHA256]::Create()
  try{return [BitConverter]::ToString($h.ComputeHash([Text.Encoding]::UTF8.GetBytes($text))).Replace('-','').ToLowerInvariant()}
  finally{$h.Dispose()}
}
function Repair-PluginJunctions([string]$Source){
  $metadata=Get-Content -LiteralPath (Join-Path $Source '.flutter-plugins-dependencies') -Raw -Encoding UTF8 | ConvertFrom-Json
  $base=[IO.Path]::GetFullPath((Join-Path $Source 'windows\flutter\ephemeral\.plugin_symlinks'))
  [IO.Directory]::CreateDirectory($base) | Out-Null
  foreach($plugin in $metadata.plugins.windows){
    if($plugin.name -notmatch '^[a-zA-Z0-9_]+$'){throw 'Invalid plugin name.'}
    $path=Join-Path $base $plugin.name
    $target=([string]$plugin.path -replace '\\{2,}','\').TrimEnd('\')
    if(-not (Test-Path -LiteralPath $target -PathType Container)){throw "Plugin cache missing: $target"}
    if(Test-Path -LiteralPath $path){
      $item=Get-Item -LiteralPath $path -Force
      if($item.LinkType -eq 'Junction' -or $item.LinkType -eq 'SymbolicLink'){[IO.Directory]::Delete($path)}
      else{[IO.Directory]::Delete($path)}
    }
    New-Item -ItemType Junction -Path $path -Target $target | Out-Null
  }
}
function Stage-LocalRuntime($Settings,[string]$Release,[string]$Candidate){
  $versions=Join-Path $Settings.installRoot 'versions'
  $target=Assert-Child $Candidate $versions
  if(Test-Path -LiteralPath $target){throw 'A new runtime must use a fresh version directory.'}
  if(-not(Test-Path -LiteralPath (Join-Path $Release 'ai_video_studio.exe'))){throw 'Compiled release missing.'}
  if(Get-ChildItem -LiteralPath $Release -Recurse -Force | Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}){throw 'Linked release rejected.'}
  & robocopy.exe $Release $target /E /XJ /R:1 /W:1 /NFL /NDL /NP /NJH /NJS | Out-Null
  if($LASTEXITCODE -ge 8){throw 'Could not stage compiled application.'}
  foreach($pair in @(@('python','third_party\python\windows-x64'),@('runtime','third_party\llama.cpp\windows-x64'),@('runtime-vulkan','third_party\llama.cpp\windows-vulkan-x64'),@('diffusion','third_party\stable-diffusion.cpp\windows-cpu-x64'),@('diffusion-vulkan','third_party\stable-diffusion.cpp\windows-vulkan-x64'),@('ocr','third_party\ocr\windows-x64'),@('tts','third_party\tts\windows-x64'),@('sources','third_party\sources'),@('licenses','third_party\licenses'),@('ffmpeg','third_party\ffmpeg\windows-x64\ffmpeg-N-127142-g12b7b9891b-win64-lgpl\bin'),@('whisper','third_party\whisper\windows-x64\Release'))){
    $from=Join-Path $Settings.source $pair[1];$to=Assert-Child (Join-Path $target $pair[0]) $target
    if(Test-Path -LiteralPath $from){
      & robocopy.exe $from $to /E /XJ /R:1 /W:1 /NFL /NDL /NP /NJH /NJS /XD __pycache__ .git /XF *.pyc | Out-Null
      if($LASTEXITCODE -ge 8){throw ('Runtime copy failed: '+$pair[0])}
    }
  }
  $maintenance=Assert-Child (Join-Path $target 'maintenance') $target
  [IO.Directory]::CreateDirectory($maintenance) | Out-Null
  foreach($name in @('Launch.ps1','Rollback.ps1','Uninstall.ps1','Update.Common.ps1','Restart-Update.ps1','Background-Update.ps1','Register-BackgroundUpdates.ps1','AI Video Studio.exe','Uninstall.exe','update-trust.json')){
    Copy-Item -LiteralPath (Join-Path $Settings.development ('packaging\'+$name)) -Destination (Join-Path $maintenance $name) -Force
  }
  [IO.File]::WriteAllText((Join-Path $target '.installed'),'shared-models-v1')
}
