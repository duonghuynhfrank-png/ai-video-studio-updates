﻿param([string]$InstallRoot=$PSScriptRoot)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Update.Common.ps1')
$root=[IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
$updates=Assert-Child (Join-Path $root 'updates') $root
$hash=[Security.Cryptography.SHA256]::Create()
try{$key=[BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($root.ToLowerInvariant()))).Replace('-','')}finally{$hash.Dispose()}
$guard=New-Object Threading.Mutex($false,('Local\AIVideoStudioBackground'+$key));$owns=$false
try{
  try{$owns=$guard.WaitOne(0)}catch [Threading.AbandonedMutexException]{$owns=$true}
  if(-not $owns){exit 0}
  if(Test-Path -LiteralPath (Join-Path $updates 'REMOTE_PAUSE')){exit 0}
  $info=Get-InstallInfo $root
  $python=Assert-Child (Join-Path $info.current 'python\python.exe') $info.current
  $client=Assert-Child (Join-Path $info.current 'python\update_client.py') $info.current
  Write-JsonAtomic (Join-Path $updates 'background-status.json') @{phase='checking';pid=$PID;at=[DateTime]::UtcNow.ToString('o')}
  # This process belongs to Task Scheduler, independent of the app's lifetime.
  $savedPreference=$ErrorActionPreference
  try{
    $ErrorActionPreference='Continue'
    $reply=& $python $client stage --root $root 2> (Join-Path $updates 'background.stderr.log')
    $exitCode=$LASTEXITCODE
  }finally{$ErrorActionPreference=$savedPreference}
  if($exitCode -ne 0){throw 'Chưa tải hoặc xác minh được cập nhật; sẽ tự thử lại.'}
  $phase='checked'
  $activation=New-Object Threading.Mutex($false,(Activation-MutexName $root));$ownsActivation=$false
  try{
    try{$ownsActivation=$activation.WaitOne(0)}catch [Threading.AbandonedMutexException]{$ownsActivation=$true}
    if($ownsActivation -and (Test-Path -LiteralPath (Join-Path $updates 'pending.json'))){
      $idle=$false
      try{Assert-Idle $root;$idle=$true}catch{}
      if($idle){[void](Activate-Pending $root);[void](Prune-Versions $root);$phase='applied'}else{$phase='waiting-for-app-close'}
    }
  }finally{if($ownsActivation){$activation.ReleaseMutex()};$activation.Dispose()}
  Write-JsonAtomic (Join-Path $updates 'background-status.json') @{phase=$phase;pid=$PID;at=[DateTime]::UtcNow.ToString('o')}
}catch{
  Write-JsonAtomic (Join-Path $updates 'background-status.json') @{phase='failed';message=$_.Exception.Message;at=[DateTime]::UtcNow.ToString('o')}
  exit 1
}finally{if($owns){$guard.ReleaseMutex()};$guard.Dispose()}
