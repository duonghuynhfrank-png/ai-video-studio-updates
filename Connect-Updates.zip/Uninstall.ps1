﻿param([string]$InstallRoot=$PSScriptRoot,[switch]$Confirmed,[switch]$CheckOnly,
      [string]$RegistrationKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIVideoStudioLocal',
      [string]$ResultPath=(Join-Path $PSScriptRoot 'uninstall-result.json'))
$ErrorActionPreference='Stop'
$locks=@();$paused=$false;$root=$null;$hasRegistration=$false;$identitySource=$null
function Result($ok,$message){
  [IO.File]::WriteAllText($ResultPath,(@{passed=$ok;message=$message;root=$root;dataPreserved=$true;identitySource=$identitySource;validationOnly=[bool]$CheckOnly;at=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json),[Text.UTF8Encoding]::new($false))
  [IO.File]::WriteAllText($ResultPath+'.txt',$message,[Text.UTF8Encoding]::new($false))
}
try{
  if(-not $Confirmed -and -not $CheckOnly){throw 'Chưa xác nhận gỡ cài đặt. Mở Uninstall.exe hoặc Gỡ cài đặt trong Windows.'}
  if($RegistrationKey -ne 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIVideoStudioLocal' -and $RegistrationKey -notmatch '^HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\AIVideoStudioFixture[0-9a-f]{32}$'){throw 'Invalid application registration.'}
  $root=[IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
  if($root -eq [IO.Path]::GetPathRoot($root).TrimEnd('\')){throw 'Không được gỡ tại thư mục gốc của ổ đĩa.'}
  $cursor=$root
  while($cursor -and $cursor -ne [IO.Path]::GetPathRoot($cursor)){
    if((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Thư mục cài đặt có liên kết. Mở trình gỡ tại thư mục thật.'}
    $cursor=[IO.Path]::GetDirectoryName($cursor)
  }
  if(-not (Test-Path -LiteralPath (Join-Path $root 'installation.json'))){throw 'Thiếu thông tin cài đặt; chưa xóa file nào.'}
  . (Join-Path $PSScriptRoot 'Update.Common.ps1')
  $info=Get-InstallInfo $root
  $registration=Get-ItemProperty -LiteralPath $RegistrationKey -ErrorAction SilentlyContinue
  if($registration){
    if(-not $registration.InstallLocation -or [IO.Path]::GetFullPath($registration.InstallLocation).TrimEnd('\') -ne $root){throw 'Thư mục này không trùng với ứng dụng được Windows đăng ký.'}
    $registered=[IO.Path]::GetFullPath($registration.InstallLocation).TrimEnd('\')
    $hasRegistration=$true;$identitySource='windows-registration'
  }else{
    # A copied/migrated install can lose its per-user uninstall entry. Verify
    # the installed application itself before accepting the explicit removal.
    $manifestPath=Assert-Child (Join-Path $info.current 'package-manifest.json') $root
    $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if($manifest.schemaVersion -ne 1 -or $manifest.target -ne 'windows-x64' -or $manifest.version -ne $info.version){throw 'Thiếu đăng ký Windows và hồ sơ cài đặt không hợp lệ. Chưa xóa file nào.'}
    foreach($name in @('.installed','ai_video_studio.exe','flutter_windows.dll','data/app.so')){
      $entries=@($manifest.files | Where-Object {$_.path -eq $name})
      if($entries.Count -ne 1){throw ('Hồ sơ cài thiếu hoặc lặp file: '+$name)}
      $file=Assert-Child (Join-Path $info.current $name) $info.current
      if(-not (Test-Path -LiteralPath $file -PathType Leaf) -or (Get-Item -LiteralPath $file).Length -ne $entries[0].bytes -or (Get-Hash $file) -ne $entries[0].sha256){throw ('File cài đặt bị thiếu hoặc thay đổi: '+$name+'. Chưa xóa file nào.')}
    }
    if([IO.File]::ReadAllText((Join-Path $info.current '.installed')) -ne 'shared-models-v1'){throw 'Installation marker invalid.'}
    $exe=(Get-Item -LiteralPath (Join-Path $info.current 'ai_video_studio.exe')).VersionInfo
    if($exe.ProductName -ne 'ai_video_studio' -or $exe.CompanyName -ne 'vn.aivideostudio' -or -not ($exe.ProductVersion -eq $info.version -or $exe.ProductVersion.StartsWith($info.version+'+') -or $exe.ProductVersion.StartsWith($info.version+'.'))){throw 'Hồ sơ không xác định được đúng ứng dụng AI Video Studio. Chưa xóa file nào.'}
    $registered=$root;$identitySource='verified-installed-package'
  }
  foreach($name in @((Activation-MutexName $root),'Local\AIVideoStudioLocalPublish')){
    $lock=New-Object Threading.Mutex($false,$name)
    if(-not $lock.WaitOne(5000)){$lock.Dispose();throw 'Ứng dụng đang cập nhật. Chờ cập nhật hoàn tất rồi gỡ lại.'}
    $locks+=$lock
  }
  $storage=Join-Path $env:LOCALAPPDATA 'AI Video Studio\storage.json'
  if(Test-Path -LiteralPath $storage){
    $support=(Get-Content -LiteralPath $storage -Raw -Encoding UTF8 | ConvertFrom-Json).supportDirectory
    if($support){$dataPath=[IO.Path]::GetFullPath($support).TrimEnd('\');if($dataPath -eq $root -or $dataPath.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Kho Data đang nằm trong thư mục App. Chuyển Data ra ngoài trước khi gỡ để giữ dự án.'}}
  }
  foreach($name in @('Data','Source','Projects')){if(Test-Path -LiteralPath (Join-Path $root $name)){throw ('Có dữ liệu người dùng trong App\'+$name+'. Chuyển dữ liệu ra ngoài trước khi gỡ.')}}
  if(Get-ChildItem -LiteralPath $root -Recurse -Force | Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}){throw 'Có file hoặc thư mục liên kết trong App. Chưa xóa file nào.'}
  if($CheckOnly){Result $true 'Đã xác minh đúng thư mục app và dữ liệu được giữ. Chỉ kiểm tra, chưa gỡ ứng dụng.';exit 0}
  # Never stop a user process. The bootstrap launcher exits before this worker starts.
  $deadline=[DateTime]::UtcNow.AddSeconds(4)
  do{
    $running=@(Get-Process | Where-Object {try{$_.Path -and $_.Path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)}catch{$false}})
    if(-not $running.Count){break};Start-Sleep -Milliseconds 200
  }while([DateTime]::UtcNow -lt $deadline)
  if($running.Count){throw 'Hãy lưu và đóng AI Video Studio cùng các tác vụ AI trước khi gỡ. Không có tiến trình nào bị dừng.'}
  $updates=Join-Path $root 'updates';[IO.Directory]::CreateDirectory($updates) | Out-Null
  $pause=Join-Path $updates 'PAUSE';$previousPause=if(Test-Path -LiteralPath $pause){[IO.File]::ReadAllBytes($pause)}else{$null}
  [IO.File]::WriteAllText($pause,'uninstall');$paused=$true
  # Both deletion targets were resolved and validated above; remain in PowerShell.
  $checked=[IO.Path]::GetFullPath($root).TrimEnd('\')
  if($checked -ne [IO.Path]::GetFullPath($registered).TrimEnd('\')){throw 'Unexpected removal path.'}
  $taskMarker=Join-Path $root 'updates\background-task.json'
  if(Test-Path -LiteralPath $taskMarker){
    $name=(Get-Content -LiteralPath $taskMarker -Raw -Encoding UTF8 | ConvertFrom-Json).taskName
    if($name -match '^AI Video Studio Updates [a-f0-9]{12}$'){
      $task=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
      if($task -and @($task.Actions | Where-Object {$_.Arguments.Contains('+$root+')}).Count){Unregister-ScheduledTask -TaskName $name -Confirm:$false}
    }
  }
  Remove-Item -LiteralPath $checked -Recurse -Force -ErrorAction Stop
  $paused=$false
  if($hasRegistration){Remove-Item -LiteralPath $RegistrationKey -Recurse -Force -ErrorAction Stop}
  $shell=New-Object -ComObject WScript.Shell
  $menu=Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\AI Video Studio'
  foreach($folder in @([Environment]::GetFolderPath('Desktop'),$menu,[Environment]::GetFolderPath('Startup'))){
    foreach($name in @('AI Video Studio.lnk','Uninstall AI Video Studio.lnk','AI Video Studio Update.lnk')){
      $path=Join-Path $folder $name
      if(Test-Path -LiteralPath $path){
        $entry=$shell.CreateShortcut($path)
        if($entry.TargetPath.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase) -or $entry.Arguments.Contains($root)){Remove-Item -LiteralPath $path -Force}
      }
    }
  }
  if((Test-Path -LiteralPath $menu) -and -not (Get-ChildItem -LiteralPath $menu -Force)){Remove-Item -LiteralPath $menu -Force}
  if($RegistrationKey.EndsWith('\AIVideoStudioLocal')){
    $task=Get-ScheduledTask -TaskName 'AI Video Studio Local Updates' -ErrorAction SilentlyContinue
    if($task -and @($task.Actions | Where-Object {$_.Arguments.Contains((Split-Path $root -Parent)) -or $_.Execute.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)}).Count){Unregister-ScheduledTask -TaskName $task.TaskName -Confirm:$false -ErrorAction SilentlyContinue}
  }
  Result $true 'Đã gỡ ứng dụng và model trong App. Project, mẫu giọng, kho Data và mã nguồn bên ngoài App được giữ.'
  exit 0
}catch{
  if($paused -and (Test-Path -LiteralPath $root)){
    if($null -ne $previousPause){[IO.File]::WriteAllBytes($pause,$previousPause)}else{Remove-Item -LiteralPath $pause -Force -ErrorAction SilentlyContinue}
  }
  Result $false $_.Exception.Message
  exit 1
}finally{foreach($lock in $locks){$lock.ReleaseMutex();$lock.Dispose()}}
