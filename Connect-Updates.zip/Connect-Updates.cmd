@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Connect-Updates.ps1"
pause
