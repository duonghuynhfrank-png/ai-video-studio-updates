﻿param([string]$InstallRoot=$PSScriptRoot,[switch]$StartNow)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Update.Common.ps1')
$root=[IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
$info=Get-InstallInfo $root
[IO.Directory]::CreateDirectory((Join-Path $root 'updates')) | Out-Null
$worker=Assert-Child (Join-Path $root 'Background-Update.ps1') $root
if(-not(Test-Path -LiteralPath $worker)){throw 'Missing background updater.'}
if($root.Contains('"')){throw 'Invalid installation path.'}
$hash=[Security.Cryptography.SHA256]::Create()
try{$key=[BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($root.ToLowerInvariant()))).Replace('-','').Substring(0,12).ToLowerInvariant()}finally{$hash.Dispose()}
$name='AI Video Studio Updates '+$key
$user=[Security.Principal.WindowsIdentity]::GetCurrent().Name
$arguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$worker+'" -InstallRoot "'+$root+'"'
$existing=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
$matches=$existing -and $existing.State -ne 'Disabled' -and @($existing.Actions | Where-Object {$_.Arguments -eq $arguments}).Count -eq 1
if(-not $matches){
  $powershell=Join-Path ([Environment]::GetFolderPath('System')) 'WindowsPowerShell\v1.0\powershell.exe'
  $action=New-ScheduledTaskAction -Execute $powershell -Argument $arguments -WorkingDirectory $root
  $logon=New-ScheduledTaskTrigger -AtLogOn -User $user
  $repeat=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 10)
  $principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
  $options=New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 3) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 2)
  Register-ScheduledTask -TaskName $name -Action $action -Trigger @($logon,$repeat) -Principal $principal -Settings $options -Force | Out-Null
}
Write-JsonAtomic (Join-Path $root 'updates\background-task.json') @{taskName=$name;intervalMinutes=10;registeredAt=[DateTime]::UtcNow.ToString('o')}
if($StartNow){Start-ScheduledTask -TaskName $name}
